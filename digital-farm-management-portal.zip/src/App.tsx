import React, { useState, useEffect } from 'react';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { 
  doc, setDoc, getDoc, collection, onSnapshot, addDoc, updateDoc, deleteDoc 
} from 'firebase/firestore';
import { auth, db, logOut, handleFirestoreError, OperationType } from './firebase';
import { 
  Role, Farm, BiosecurityChecklist, VisitorLog, HealthRecord, 
  Vaccination, DailyRecord, SystemNotification 
} from './types';
import { seedMockData } from './seeder';

// Component Imports
import Auth from './components/Auth';
import Dashboard from './components/Dashboard';
import FarmManagement from './components/FarmManagement';
import Biosecurity from './components/BiosecurityChecklist';
import AnimalHealth from './components/AnimalHealth';
import VaccinationHub from './components/Vaccination';
import DailyRecords from './components/DailyRecords';
import Reports from './components/Reports';
import Settings from './components/Settings';

// Icon Imports
import { 
  Sprout, Shield, ShieldCheck, Heart, Syringe, Clipboard, 
  FileText, Settings as SettingsIcon, LogOut as LogOutIcon, 
  Bell, Menu, X, Activity, AlertTriangle 
} from 'lucide-react';

export default function App() {
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [role, setRole] = useState<Role>('Farmer');
  const [displayName, setDisplayName] = useState('Farmer');
  const [darkMode, setDarkMode] = useState(false);

  // Database States
  const [farms, setFarms] = useState<Farm[]>([]);
  const [checklists, setChecklists] = useState<BiosecurityChecklist[]>([]);
  const [visitorLogs, setVisitorLogs] = useState<VisitorLog[]>([]);
  const [healthRecords, setHealthRecords] = useState<HealthRecord[]>([]);
  const [vaccinations, setVaccinations] = useState<Vaccination[]>([]);
  const [dailyRecords, setDailyRecords] = useState<DailyRecord[]>([]);

  // Navigation & UI States
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [notifications, setNotifications] = useState<SystemNotification[]>([]);

  // 1. Auth Change Listener
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (firebaseUser) => {
      setLoading(true);
      if (firebaseUser) {
        setCurrentUser(firebaseUser);
        setDisplayName(firebaseUser.displayName || 'Farmer');
        
        // Fetch User profile from Firestore
        try {
          const userRef = doc(db, 'users', firebaseUser.uid);
          const userSnap = await getDoc(userRef);
          if (userSnap.exists()) {
            setRole(userSnap.data().role as Role);
            setDisplayName(userSnap.data().displayName || firebaseUser.displayName || 'Farmer');
          } else {
            // Setup default profile
            await setDoc(userRef, {
              uid: firebaseUser.uid,
              email: firebaseUser.email || '',
              displayName: firebaseUser.displayName || 'Farmer',
              role: 'Farmer',
              createdAt: new Date().toISOString()
            });
            setRole('Farmer');
          }
        } catch (err) {
          console.error('Error loading user profile:', err);
        }
      } else {
        // Look for simulated/demo login
        const savedDemoRole = localStorage.getItem('demo_role');
        const savedDemoName = localStorage.getItem('demo_name');
        
        if (savedDemoRole && savedDemoName) {
          setRole(savedDemoRole as Role);
          setDisplayName(savedDemoName);
          setCurrentUser({ uid: `demo_${savedDemoRole.toLowerCase().replace(' ', '_')}` } as any);
        } else {
          setCurrentUser(null);
        }
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // 2. Real-time Database Listeners for Active Farms and nested subcollections
  useEffect(() => {
    if (!currentUser) {
      setFarms([]);
      return;
    }

    setLoading(true);
    // Sync Farms
    const path = 'farms';
    const unsubFarms = onSnapshot(collection(db, path), (snapshot) => {
      const loadedFarms = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as Farm));
      setFarms(loadedFarms);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    });

    return () => unsubFarms();
  }, [currentUser]);

  // Sync Subcollections for all Farms dynamically
  useEffect(() => {
    if (farms.length === 0) {
      setChecklists([]);
      setVisitorLogs([]);
      setHealthRecords([]);
      setVaccinations([]);
      setDailyRecords([]);
      return;
    }

    const unsubscribes: (() => void)[] = [];

    // Aggregate temporary objects to prevent intermediate flashes
    const checklistsMap: { [id: string]: BiosecurityChecklist } = {};
    const visitorLogsMap: { [id: string]: VisitorLog } = {};
    const healthRecordsMap: { [id: string]: HealthRecord } = {};
    const vaccinationsMap: { [id: string]: Vaccination } = {};
    const dailyRecordsMap: { [id: string]: DailyRecord } = {};

    farms.forEach((farm) => {
      // checklists
      const unsubC = onSnapshot(collection(db, 'farms', farm.id, 'biosecurityChecklists'), (snapshot) => {
        snapshot.docs.forEach(doc => {
          checklistsMap[doc.id] = { id: doc.id, ...doc.data() } as BiosecurityChecklist;
        });
        setChecklists(Object.values(checklistsMap));
      }, (error) => {
        console.error('Checklist error:', error);
      });
      unsubscribes.push(unsubC);

      // visitors
      const unsubV = onSnapshot(collection(db, 'farms', farm.id, 'visitorLogs'), (snapshot) => {
        snapshot.docs.forEach(doc => {
          visitorLogsMap[doc.id] = { id: doc.id, ...doc.data() } as VisitorLog;
        });
        setVisitorLogs(Object.values(visitorLogsMap));
      }, (error) => {
        console.error('Visitor logs error:', error);
      });
      unsubscribes.push(unsubV);

      // health
      const unsubH = onSnapshot(collection(db, 'farms', farm.id, 'healthRecords'), (snapshot) => {
        snapshot.docs.forEach(doc => {
          healthRecordsMap[doc.id] = { id: doc.id, ...doc.data() } as HealthRecord;
        });
        setHealthRecords(Object.values(healthRecordsMap));
      }, (error) => {
        console.error('Health records error:', error);
      });
      unsubscribes.push(unsubH);

      // vaccinations
      const unsubVacc = onSnapshot(collection(db, 'farms', farm.id, 'vaccinations'), (snapshot) => {
        snapshot.docs.forEach(doc => {
          vaccinationsMap[doc.id] = { id: doc.id, ...doc.data() } as Vaccination;
        });
        setVaccinations(Object.values(vaccinationsMap));
      }, (error) => {
        console.error('Vaccination error:', error);
      });
      unsubscribes.push(unsubVacc);

      // daily performance records
      const unsubD = onSnapshot(collection(db, 'farms', farm.id, 'dailyRecords'), (snapshot) => {
        snapshot.docs.forEach(doc => {
          dailyRecordsMap[doc.id] = { id: doc.id, ...doc.data() } as DailyRecord;
        });
        setDailyRecords(Object.values(dailyRecordsMap));
      }, (error) => {
        console.error('Daily records error:', error);
      });
      unsubscribes.push(unsubD);
    });

    return () => unsubscribes.forEach(unsub => unsub());
  }, [farms]);

  // 3. Dynamic Alerts and Notifications Engine
  useEffect(() => {
    const list: SystemNotification[] = [];

    // Trigger vaccine overdue notification
    vaccinations.forEach(v => {
      const isOverdue = v.status === 'overdue' || (v.status === 'scheduled' && new Date(v.nextDueDate) < new Date());
      if (isOverdue) {
        const farmObj = farms.find(f => f.id === v.farmId);
        list.push({
          id: `notif_vacc_${v.id}`,
          title: 'Overdue Vaccination',
          message: `${v.vaccineName} dose is overdue for ${farmObj?.name || 'Farm'}.`,
          type: 'alert',
          createdAt: new Date().toISOString(),
          read: false
        });
      }
    });

    // Low biosecurity score warning
    checklists.forEach(c => {
      if (c.compliancePercentage < 90) {
        const farmObj = farms.find(f => f.id === c.farmId);
        list.push({
          id: `notif_checklist_${c.id}`,
          title: 'Biosecurity Concern',
          message: `Daily checklist scored low compliance (${c.compliancePercentage}%) at ${farmObj?.name || 'Farm'}.`,
          type: 'warning',
          createdAt: c.createdAt,
          read: false
        });
      }
    });

    // Sickness outbreaks alert
    healthRecords.forEach(h => {
      const farmObj = farms.find(f => f.id === h.farmId);
      list.push({
        id: `notif_health_${h.id}`,
        title: 'Active Illness Reported',
        message: `${h.disease} reported at ${farmObj?.name || 'Farm'}. Isolation and disinfection ordered.`,
        type: 'warning',
        createdAt: h.createdAt,
        read: false
      });
    });

    setNotifications(list);
  }, [vaccinations, checklists, healthRecords, farms]);

  // Handle Authentication Success (Google or Demo Account)
  const handleAuthSuccess = async (selectedRole: Role, selectedName: string) => {
    setRole(selectedRole);
    setDisplayName(selectedName);
    
    // For demo account simulation persist local storage so reload holds login
    localStorage.setItem('demo_role', selectedRole);
    localStorage.setItem('demo_name', selectedName);
    
    setCurrentUser({ uid: `demo_${selectedRole.toLowerCase().replace(' ', '_')}` } as any);
  };

  // Log out of session
  const handleLogOut = async () => {
    localStorage.removeItem('demo_role');
    localStorage.removeItem('demo_name');
    setCurrentUser(null);
    await logOut();
  };

  // Update Profile Name/Role
  const handleUpdateProfile = async (newName: string, newRole: Role) => {
    setDisplayName(newName);
    setRole(newRole);
    localStorage.setItem('demo_name', newName);
    localStorage.setItem('demo_role', newRole);
    
    if (currentUser && !currentUser.uid.startsWith('demo_')) {
      try {
        await setDoc(doc(db, 'users', currentUser.uid), {
          uid: currentUser.uid,
          email: currentUser.email || '',
          displayName: newName,
          role: newRole,
          createdAt: new Date().toISOString()
        });
      } catch (err) {
        console.error('Failed to sync user profile updates to Firestore:', err);
      }
    }
  };

  // DB CRUD Operations
  const handleAddFarm = async (farmInput: Omit<Farm, 'id' | 'ownerId' | 'createdAt'>) => {
    if (!currentUser) return;
    const path = 'farms';
    try {
      const ref = collection(db, path);
      await addDoc(ref, {
        ...farmInput,
        ownerId: currentUser.uid,
        createdAt: new Date().toISOString()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  };

  const handleEditFarm = async (id: string, updated: Partial<Farm>) => {
    const path = `farms/${id}`;
    try {
      const ref = doc(db, 'farms', id);
      await updateDoc(ref, updated);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  };

  const handleDeleteFarm = async (id: string) => {
    const path = `farms/${id}`;
    try {
      const ref = doc(db, 'farms', id);
      await deleteDoc(ref);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  };

  // Checklist Submissions
  const handleAddChecklist = async (checklist: Omit<BiosecurityChecklist, 'id' | 'completedBy' | 'createdAt'>) => {
    const path = `farms/${checklist.farmId}/biosecurityChecklists`;
    try {
      const ref = collection(db, 'farms', checklist.farmId, 'biosecurityChecklists');
      await addDoc(ref, {
        ...checklist,
        completedBy: displayName,
        createdAt: new Date().toISOString()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  };

  // Visitor log entry
  const handleAddVisitorLog = async (log: Omit<VisitorLog, 'id' | 'loggedBy'>) => {
    const path = `farms/${log.farmId}/visitorLogs`;
    try {
      const ref = collection(db, 'farms', log.farmId, 'visitorLogs');
      await addDoc(ref, {
        ...log,
        loggedBy: displayName
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  };

  const handleToggleVisitorClearance = async (farmId: string, logId: string, cleared: boolean) => {
    const path = `farms/${farmId}/visitorLogs/${logId}`;
    try {
      const ref = doc(db, 'farms', farmId, 'visitorLogs', logId);
      await updateDoc(ref, { cleared });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  };

  // Sickness record
  const handleAddHealthRecord = async (record: Omit<HealthRecord, 'id' | 'recordedBy' | 'createdAt'>) => {
    const path = `farms/${record.farmId}/healthRecords`;
    try {
      const ref = collection(db, 'farms', record.farmId, 'healthRecords');
      await addDoc(ref, {
        ...record,
        recordedBy: displayName,
        createdAt: new Date().toISOString()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  };

  // Immunization Record
  const handleAddVaccination = async (vacc: Omit<Vaccination, 'id' | 'recordedBy' | 'createdAt'>) => {
    const path = `farms/${vacc.farmId}/vaccinations`;
    try {
      const ref = collection(db, 'farms', vacc.farmId, 'vaccinations');
      await addDoc(ref, {
        ...vacc,
        recordedBy: displayName,
        createdAt: new Date().toISOString()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  };

  const handleMarkVaccinated = async (farmId: string, vaccId: string) => {
    const path = `farms/${farmId}/vaccinations/${vaccId}`;
    try {
      const ref = doc(db, 'farms', farmId, 'vaccinations', vaccId);
      await updateDoc(ref, {
        status: 'completed'
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  };

  // Daily records
  const handleAddDailyRecord = async (record: Omit<DailyRecord, 'id' | 'recordedBy' | 'createdAt'>) => {
    const path = `farms/${record.farmId}/dailyRecords`;
    try {
      const ref = collection(db, 'farms', record.farmId, 'dailyRecords');
      await addDoc(ref, {
        ...record,
        recordedBy: displayName,
        createdAt: new Date().toISOString()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  };

  // Firestore Seed Datasets
  const handleSeedDemoData = async () => {
    if (!currentUser) return;
    await seedMockData(currentUser.uid);
  };

  // Nav Tabs configuration
  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: Activity },
    { id: 'farms', label: 'Farms Log', icon: Sprout },
    { id: 'biosecurity', label: 'Biosecurity Check', icon: ShieldCheck },
    { id: 'health', label: 'Animal Health', icon: Heart },
    { id: 'vaccinations', label: 'Vaccines Hub', icon: Syringe },
    { id: 'daily', label: 'Daily husbandries', icon: Clipboard },
    { id: 'reports', label: 'PDF Reports', icon: FileText },
    { id: 'settings', label: 'Settings', icon: SettingsIcon }
  ];

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-stone-50 text-stone-600">
        <div className="animate-spin h-10 w-10 border-4 border-emerald-600 border-t-transparent rounded-full mb-3"></div>
        <span className="text-xs font-mono font-bold uppercase tracking-widest text-emerald-800">Initializing Portal...</span>
      </div>
    );
  }

  if (!currentUser) {
    return <Auth onAuthSuccess={handleAuthSuccess} />;
  }

  const activeTabDetails = tabs.find(t => t.id === activeTab);

  return (
    <div className={`min-h-screen bg-[#F4F7F5] flex flex-col font-sans selection:bg-emerald-100 ${darkMode ? 'dark text-stone-100 bg-[#121614]' : 'text-[#062416]'}`}>
      
      {/* GLOBAL TOP NAV BAR */}
      <header className="bg-white/90 dark:bg-stone-900/90 backdrop-blur-md border-b border-stone-200/40 h-16 flex items-center justify-between px-6 sm:px-8 sticky top-0 z-40 shadow-sm shrink-0">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 hover:bg-stone-50 dark:hover:bg-stone-800 rounded-xl lg:hidden cursor-pointer transition"
          >
            <Menu className="h-5 w-5 text-stone-600 dark:text-stone-300" />
          </button>
          <div className="flex items-center gap-2">
            <Sprout className="h-6 w-6 text-emerald-600 dark:text-emerald-400 shrink-0 animate-pulse" />
            <span className="font-extrabold text-[#062416] dark:text-stone-100 tracking-tight text-sm sm:text-base">DIGITAL FARM PORTAL</span>
          </div>
        </div>

        <div className="flex items-center gap-4">
          
          {/* Notifications alert button */}
          <div className="relative">
            <button
              onClick={() => setNotificationsOpen(!notificationsOpen)}
              className="p-2.5 text-stone-500 dark:text-stone-400 hover:text-emerald-700 dark:hover:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-xl transition relative cursor-pointer"
            >
              <Bell className="h-5 w-5" />
              {notifications.length > 0 && (
                <span className="absolute top-1.5 right-1.5 h-2 w-2 bg-rose-500 rounded-full animate-ping"></span>
              )}
            </button>

            {/* Notifications Popover Dropdown */}
            {notificationsOpen && (
              <div className="absolute right-0 mt-3 w-80 bg-white dark:bg-stone-900 border border-stone-200/50 dark:border-stone-800 shadow-xl rounded-[1.5rem] p-5 space-y-3 z-50 text-xs text-left max-h-96 overflow-y-auto">
                <div className="flex justify-between items-center pb-2 border-b border-stone-100 dark:border-stone-800">
                  <span className="font-bold text-stone-900 dark:text-stone-100 text-sm">System Alerts ({notifications.length})</span>
                  <button onClick={() => setNotificationsOpen(false)} className="text-stone-400 hover:text-stone-600">
                    <X className="h-4 w-4" />
                  </button>
                </div>

                {notifications.length === 0 ? (
                  <p className="text-center py-4 text-stone-400 font-medium">All systems green. Zero active biohazards.</p>
                ) : (
                  <div className="space-y-2.5">
                    {notifications.map((notif) => (
                      <div key={notif.id} className="p-3 bg-stone-50 dark:bg-stone-800/50 border border-stone-200/50 dark:border-stone-700 rounded-xl flex gap-2.5 items-start">
                        {notif.type === 'alert' ? (
                          <AlertTriangle className="h-4 w-4 text-rose-500 shrink-0 mt-0.5" />
                        ) : (
                          <Shield className="h-4 w-4 text-amber-500 shrink-0 mt-0.5" />
                        )}
                        <div>
                          <p className="font-bold text-stone-900 dark:text-stone-100">{notif.title}</p>
                          <p className="text-stone-600 dark:text-stone-300 text-[10px] leading-normal mt-0.5">{notif.message}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* User profile capsule */}
          <div className="hidden sm:flex items-center gap-2.5 px-4 py-1.5 bg-[#f4f7f5] dark:bg-stone-800 border border-stone-200/30 dark:border-stone-700 rounded-full text-xs">
            <span className="font-bold text-stone-800 dark:text-stone-200">{displayName}</span>
            <span className="h-3 w-px bg-stone-300 dark:bg-stone-600"></span>
            <span className="text-emerald-700 dark:text-emerald-400 font-mono text-[10px] font-bold uppercase tracking-wider">{role}</span>
          </div>

        </div>
      </header>

      {/* CORE WRAPPER LAYOUT */}
      <div className="flex flex-1 relative overflow-hidden">
        
        {/* DESKTOP SIDEBAR NAVIGATION (Bento Floating Panel) */}
        <aside className={`bg-white dark:bg-stone-900 border border-stone-200/60 dark:border-stone-800 rounded-[2rem] w-64 p-5 my-4 ml-4 flex flex-col justify-between shrink-0 relative shadow-sm ${
          sidebarOpen ? 'absolute inset-y-0 left-0 z-35 shadow-xl my-4 ml-4' : 'hidden lg:flex'
        }`}>
          <div className="space-y-6">
            <div className="flex justify-between items-center lg:hidden">
              <span className="font-extrabold text-xs text-stone-400 uppercase tracking-wider font-mono">Main Directory</span>
              <button onClick={() => setSidebarOpen(false)} className="p-1.5 hover:bg-stone-50 dark:hover:bg-stone-800 rounded-lg">
                <X className="h-5 w-5 text-stone-500" />
              </button>
            </div>

            <nav className="space-y-1">
              {tabs.map((tab) => {
                const TabIcon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => {
                      setActiveTab(tab.id);
                      setSidebarOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-xs font-bold transition cursor-pointer ${
                      isActive 
                        ? 'bg-emerald-900 text-white shadow-sm dark:bg-emerald-800' 
                        : 'text-stone-600 dark:text-stone-300 hover:bg-[#F4F7F5] dark:hover:bg-stone-800 hover:text-stone-950 dark:hover:text-white'
                    }`}
                  >
                    <TabIcon className={`h-5 w-5 shrink-0 ${isActive ? 'text-emerald-300' : 'text-stone-400 dark:text-stone-500'}`} />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          <div className="pt-4 border-t border-stone-100 dark:border-stone-800">
            <button
              onClick={handleLogOut}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-rose-50 hover:bg-rose-100 text-rose-800 dark:bg-rose-950/20 dark:hover:bg-rose-950/40 dark:text-rose-400 border border-rose-100/40 dark:border-rose-900/30 rounded-2xl font-extrabold text-xs transition cursor-pointer"
            >
              <LogOutIcon className="h-4 w-4 shrink-0" />
              <span>Log Out Session</span>
            </button>
          </div>
        </aside>

        {/* MAIN BODY WINDOW */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-8 pb-24 lg:pb-8">
          
          {/* TAB SHELL DISPATCHER */}
          {activeTab === 'dashboard' && (
            <Dashboard 
              farms={farms} 
              checklists={checklists} 
              vaccinations={vaccinations} 
              healthRecords={healthRecords} 
              role={role}
              onNavigate={setActiveTab}
            />
          )}

          {activeTab === 'farms' && (
            <FarmManagement 
              farms={farms} 
              role={role}
              onAddFarm={handleAddFarm}
              onEditFarm={handleEditFarm}
              onDeleteFarm={handleDeleteFarm}
            />
          )}

          {activeTab === 'biosecurity' && (
            <Biosecurity 
              farms={farms} 
              checklists={checklists} 
              visitorLogs={visitorLogs} 
              role={role}
              onAddChecklist={handleAddChecklist}
              onAddVisitorLog={handleAddVisitorLog}
              onToggleVisitorClearance={handleToggleVisitorClearance}
            />
          )}

          {activeTab === 'health' && (
            <AnimalHealth 
              farms={farms} 
              healthRecords={healthRecords} 
              role={role}
              onAddHealthRecord={handleAddHealthRecord}
            />
          )}

          {activeTab === 'vaccinations' && (
            <VaccinationHub 
              farms={farms} 
              vaccinations={vaccinations} 
              role={role}
              onAddVaccination={handleAddVaccination}
              onMarkVaccinated={handleMarkVaccinated}
            />
          )}

          {activeTab === 'daily' && (
            <DailyRecords 
              farms={farms} 
              dailyRecords={dailyRecords} 
              role={role}
              onAddDailyRecord={handleAddDailyRecord}
            />
          )}

          {activeTab === 'reports' && (
            <Reports 
              farms={farms} 
              checklists={checklists} 
              vaccinations={vaccinations} 
              healthRecords={healthRecords} 
              dailyRecords={dailyRecords}
            />
          )}

          {activeTab === 'settings' && (
            <Settings 
              displayName={displayName} 
              role={role}
              onUpdateProfile={handleUpdateProfile}
              onLogOut={handleLogOut}
              onSeedDemoData={handleSeedDemoData}
              darkMode={darkMode}
              onToggleDarkMode={() => setDarkMode(!darkMode)}
            />
          )}

        </main>

        {/* MOBILE BOTTOM NAVIGATION BAR */}
        <nav className="lg:hidden fixed bottom-0 left-0 right-0 h-16 bg-white dark:bg-stone-900 border-t border-stone-200/60 dark:border-stone-800 flex justify-around items-center px-2 z-30 shadow-lg">
          {tabs.slice(0, 5).map((tab) => {
            const TabIcon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex flex-col items-center justify-center p-2 rounded-xl transition cursor-pointer ${
                  isActive ? 'text-emerald-700 font-extrabold dark:text-emerald-400' : 'text-stone-400'
                }`}
              >
                <TabIcon className="h-5.5 w-5.5 shrink-0" />
                <span className="text-[9px] mt-0.5 tracking-tight font-medium">{tab.label.split(' ')[0]}</span>
              </button>
            );
          })}
          {/* More menu button to go to settings / reports */}
          <button
            onClick={() => setActiveTab('settings')}
            className={`flex flex-col items-center justify-center p-2 rounded-xl transition cursor-pointer ${
              activeTab === 'settings' || activeTab === 'reports' ? 'text-emerald-700 font-extrabold dark:text-emerald-400' : 'text-stone-400'
            }`}
          >
            <SettingsIcon className="h-5.5 w-5.5 shrink-0" />
            <span className="text-[9px] mt-0.5 tracking-tight font-medium">Settings</span>
          </button>
        </nav>

      </div>
    </div>
  );
}
