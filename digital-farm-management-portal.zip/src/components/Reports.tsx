import React, { useState } from 'react';
import { motion } from 'motion/react';
import { jsPDF } from 'jspdf';
import { FileText, FileDown, Calendar, Filter, ShieldCheck, ShieldAlert, Sparkles, TrendingUp } from 'lucide-react';
import { Farm, BiosecurityChecklist, Vaccination, HealthRecord, DailyRecord, Role } from '../types';

interface ReportsProps {
  farms: Farm[];
  checklists: BiosecurityChecklist[];
  vaccinations: Vaccination[];
  healthRecords: HealthRecord[];
  dailyRecords: DailyRecord[];
}

type ReportType = 'biosecurity' | 'vaccination' | 'health' | 'performance';
type DateScope = 'today' | 'weekly' | 'monthly';

export default function Reports({ 
  farms, 
  checklists, 
  vaccinations, 
  healthRecords, 
  dailyRecords 
}: ReportsProps) {

  const [selectedFarmId, setSelectedFarmId] = useState<string>(farms[0]?.id || '');
  const [reportType, setReportType] = useState<ReportType>('biosecurity');
  const [dateScope, setDateScope] = useState<DateScope>('weekly');

  const [generating, setGenerating] = useState(false);

  const selectedFarmObj = farms.find(f => f.id === selectedFarmId);

  // Filter records based on Date Scope
  const filterByDate = (createdAtStr: string) => {
    const recordDate = new Date(createdAtStr);
    const today = new Date();
    
    if (dateScope === 'today') {
      return recordDate.toDateString() === today.toDateString();
    }
    if (dateScope === 'weekly') {
      const sevenDaysAgo = new Date(today.getTime() - (7 * 24 * 60 * 60 * 1000));
      return recordDate >= sevenDaysAgo;
    }
    if (dateScope === 'monthly') {
      const thirtyDaysAgo = new Date(today.getTime() - (30 * 24 * 60 * 60 * 1000));
      return recordDate >= thirtyDaysAgo;
    }
    return true;
  };

  // Compile data based on selected type and scope
  const activeChecklists = checklists.filter(c => c.farmId === selectedFarmId && filterByDate(c.createdAt));
  const activeVaccinations = vaccinations.filter(v => v.farmId === selectedFarmId && filterByDate(v.createdAt));
  const activeHealth = healthRecords.filter(h => h.farmId === selectedFarmId && filterByDate(h.createdAt));
  const activeDaily = dailyRecords.filter(d => d.farmId === selectedFarmId && filterByDate(d.createdAt));

  // Export as PDF function
  const handleExportPDF = () => {
    if (!selectedFarmObj) {
      alert('Select a farm first.');
      return;
    }

    setGenerating(true);
    try {
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      // Header Banner Accent
      doc.setFillColor(5, 150, 105); // Emerald Green
      doc.rect(0, 0, 210, 40, 'F');

      // Title Block
      doc.setTextColor(255, 255, 255);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(22);
      doc.text('DIGITAL FARM PORTAL', 15, 18);
      
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10);
      doc.text('OFFICIAL BIOSECURITY AUDIT & DATA LEDGER', 15, 25);
      doc.text(`Generated on: ${new Date().toLocaleString()}`, 15, 32);

      // Farm Info Block
      doc.setTextColor(50, 50, 50);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(14);
      doc.text('FACILITY DETAILS', 15, 52);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10);
      doc.text(`Farm Name:     ${selectedFarmObj.name}`, 15, 58);
      doc.text(`Location:      ${selectedFarmObj.location}`, 15, 63);
      doc.text(`Farm Type:     ${selectedFarmObj.farmType}`, 15, 68);
      doc.text(`Livestock:     ${selectedFarmObj.animalCount.toLocaleString()} heads`, 15, 73);

      // Separator Line
      doc.setDrawColor(220, 220, 220);
      doc.line(15, 80, 195, 80);

      // Report Header Block
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(13);
      const uppercaseType = reportType.toUpperCase();
      const uppercaseScope = dateScope.toUpperCase();
      doc.text(`${uppercaseType} COMPILATION REPORT - ${uppercaseScope}`, 15, 90);

      let startY = 100;

      // 1. Biosecurity Checklist Report
      if (reportType === 'biosecurity') {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10);
        // Table Headers
        doc.text('Date', 15, startY);
        doc.text('Score', 50, startY);
        doc.text('Status', 80, startY);
        doc.text('Audited By', 120, startY);

        doc.line(15, startY + 2, 195, startY + 2);
        startY += 8;

        doc.setFont('helvetica', 'normal');
        if (activeChecklists.length === 0) {
          doc.text('No biosecurity compliance records found in specified date range.', 15, startY);
        } else {
          activeChecklists.forEach((c) => {
            if (startY > 270) { doc.addPage(); startY = 20; }
            doc.text(c.date, 15, startY);
            doc.text(`${c.compliancePercentage}%`, 50, startY);
            doc.text(c.status.toUpperCase(), 80, startY);
            doc.text(c.completedBy, 120, startY);
            startY += 8;
          });
        }
      }

      // 2. Vaccination Report
      else if (reportType === 'vaccination') {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10);
        // Table Headers
        doc.text('Vaccine Name', 15, startY);
        doc.text('Admin Date', 65, startY);
        doc.text('Booster Due', 105, startY);
        doc.text('Status', 145, startY);

        doc.line(15, startY + 2, 195, startY + 2);
        startY += 8;

        doc.setFont('helvetica', 'normal');
        if (activeVaccinations.length === 0) {
          doc.text('No immunization records scheduled or logged in specified range.', 15, startY);
        } else {
          activeVaccinations.forEach((v) => {
            if (startY > 270) { doc.addPage(); startY = 20; }
            doc.text(v.vaccineName, 15, startY);
            doc.text(v.scheduleDate, 65, startY);
            doc.text(v.nextDueDate, 105, startY);
            doc.text(v.status.toUpperCase(), 145, startY);
            startY += 8;
          });
        }
      }

      // 3. Animal Disease Report
      else if (reportType === 'health') {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10);
        // Table Headers
        doc.text('Disease Condition', 15, startY);
        doc.text('Observed Symptoms', 60, startY);
        doc.text('Treatment/Rx Protocol', 120, startY);
        doc.text('Date Reported', 170, startY);

        doc.line(15, startY + 2, 195, startY + 2);
        startY += 8;

        doc.setFont('helvetica', 'normal');
        if (activeHealth.length === 0) {
          doc.text('No illness or disease records logged in specified range.', 15, startY);
        } else {
          activeHealth.forEach((h) => {
            if (startY > 260) { doc.addPage(); startY = 20; }
            doc.text(h.disease, 15, startY);
            doc.text(h.symptoms.slice(0, 25), 60, startY);
            doc.text(h.treatment.slice(0, 22), 120, startY);
            doc.text(new Date(h.createdAt).toLocaleDateString(), 170, startY);
            startY += 10;
          });
        }
      }

      // 4. Husbandry Performance Logs
      else if (reportType === 'performance') {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10);
        // Table Headers
        doc.text('Date', 15, startY);
        doc.text('Feed (kg)', 45, startY);
        doc.text('Water (L)', 75, startY);
        doc.text('Mortality', 105, startY);
        doc.text('Avg Weight (kg)', 135, startY);

        doc.line(15, startY + 2, 195, startY + 2);
        startY += 8;

        doc.setFont('helvetica', 'normal');
        if (activeDaily.length === 0) {
          doc.text('No husbandry daily consumption logs found in range.', 15, startY);
        } else {
          activeDaily.forEach((d) => {
            if (startY > 270) { doc.addPage(); startY = 20; }
            doc.text(d.date, 15, startY);
            doc.text(`${d.feedConsumption} kg`, 45, startY);
            doc.text(`${d.waterConsumption} L`, 75, startY);
            doc.text(`${d.mortalityCount} heads`, 105, startY);
            doc.text(`${d.averageWeight} kg`, 135, startY);
            startY += 8;
          });
        }
      }

      // Signature & Stamp Placeholder at Bottom
      const footerY = 270;
      doc.setDrawColor(200, 200, 200);
      doc.line(15, footerY - 15, 195, footerY - 15);
      
      doc.setFontSize(8);
      doc.setFont('helvetica', 'italic');
      doc.text('This is an authenticated biosecurity report compiled from Digital Farm Portal live Firestore registers.', 15, footerY - 8);
      doc.text('Verify compliance barcodes at national veterinary departments.', 15, footerY - 4);
      
      doc.setFont('helvetica', 'bold');
      doc.text('OFFICIAL GATE STAMP:', 145, footerY - 8);

      doc.save(`farm_report_${reportType}_${selectedFarmObj.name.toLowerCase().replace(/\s+/g, '_')}.pdf`);
    } catch (err) {
      console.error(err);
      alert('Failed to construct PDF report.');
    } finally {
      setGenerating(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-6"
    >
      <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
        <h3 className="font-extrabold text-stone-900 text-lg flex items-center gap-2">
          <FileText className="h-5.5 w-5.5 text-emerald-600" />
          Aggregated PDF Reports Center
        </h3>
        <p className="text-stone-500 text-xs mt-1">Select parameters below to construct and preview compliance/veterinary records, and download print-ready PDF certificates</p>

        {/* Filter Toolbar */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6 p-4 bg-stone-50 rounded-xl border border-stone-150">
          
          <div className="space-y-1">
            <label className="text-xs font-bold text-stone-700 block flex items-center gap-1">
              <Filter className="h-3.5 w-3.5 text-stone-400" /> Select Farm Unit
            </label>
            <select
              value={selectedFarmId}
              onChange={(e) => setSelectedFarmId(e.target.value)}
              className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-semibold"
            >
              {farms.length === 0 ? (
                <option value="">No farms registered</option>
              ) : (
                farms.map(f => (
                  <option key={f.id} value={f.id}>{f.name} ({f.farmType})</option>
                ))
              )}
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-stone-700 block">Report Module</label>
            <select
              value={reportType}
              onChange={(e) => setReportType(e.target.value as ReportType)}
              className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-semibold"
            >
              <option value="biosecurity">🛡️ Daily Biosecurity Compliance</option>
              <option value="vaccination">💉 Vaccination & Reminders Logs</option>
              <option value="health">🩺 Disease & Veterinary Visits</option>
              <option value="performance">📈 Husbandry Performance (Feed/Water)</option>
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-stone-700 block flex items-center gap-1">
              <Calendar className="h-3.5 w-3.5 text-stone-400" /> Date Filter Range
            </label>
            <select
              value={dateScope}
              onChange={(e) => setDateScope(e.target.value as DateScope)}
              className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-semibold"
            >
              <option value="today">Today (Last 24 Hours)</option>
              <option value="weekly">Weekly (Last 7 Days)</option>
              <option value="monthly">Monthly (Last 30 Days)</option>
            </select>
          </div>

        </div>

        {/* Compile preview action */}
        {selectedFarmObj && (
          <div className="flex justify-between items-center mt-6 pt-4 border-t border-stone-100">
            <div className="text-xs text-stone-500 font-medium">
              Report compiles <strong className="text-emerald-700 font-bold">
                {reportType === 'biosecurity' ? activeChecklists.length : reportType === 'vaccination' ? activeVaccinations.length : reportType === 'health' ? activeHealth.length : activeDaily.length} rows
              </strong> in specified filters.
            </div>
            <button
              onClick={handleExportPDF}
              disabled={generating}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-5 py-2.5 rounded-xl flex items-center gap-1.5 transition shadow-sm cursor-pointer"
            >
              <FileDown className="h-4.5 w-4.5" />
              {generating ? 'Compiling PDF...' : 'Export PDF Document'}
            </button>
          </div>
        )}
      </div>

      {/* Browser report preview sheet */}
      {selectedFarmObj && (
        <div className="bg-white p-8 rounded-2xl border border-stone-250 shadow-sm max-w-4xl mx-auto space-y-6">
          {/* Mock Letterhead Header */}
          <div className="flex justify-between items-center pb-5 border-b-2 border-stone-200">
            <div>
              <span className="text-emerald-600 font-mono text-[10px] uppercase tracking-widest font-black block">Official Auditor Sheet</span>
              <h4 className="text-xl font-black text-stone-900 tracking-tight mt-0.5">DIGITAL FARM PORTAL REPORT</h4>
              <p className="text-stone-400 text-[10px] font-mono mt-1">VETERINARY COMPLIANCE CERTIFICATE</p>
            </div>
            <div className="text-right text-xs">
              <span className="font-bold text-stone-700 block">Unit: {selectedFarmObj.name}</span>
              <span className="text-stone-500 block">Location: {selectedFarmObj.location}</span>
              <span className="text-stone-400 font-mono text-[10px]">Scope: {dateScope.toUpperCase()}</span>
            </div>
          </div>

          {/* Compiled contents based on select */}
          {reportType === 'biosecurity' && (
            <div className="space-y-4">
              <h5 className="font-bold text-stone-800 text-xs uppercase tracking-wider">🛡️ Biosecurity Checklists Audit</h5>
              {activeChecklists.length === 0 ? (
                <div className="text-center py-8 text-stone-400 text-xs italic">No matching biosecurity records.</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-stone-50 text-stone-500 font-bold border-b border-stone-100">
                        <th className="py-2.5 px-3">Date</th>
                        <th className="py-2.5 px-3">Compliance %</th>
                        <th className="py-2.5 px-3">Clearance Status</th>
                        <th className="py-2.5 px-3">Audited By</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-50 text-stone-700">
                      {activeChecklists.map(c => (
                        <tr key={c.id}>
                          <td className="py-2 px-3 font-mono">{c.date}</td>
                          <td className="py-2 px-3 font-bold">{c.compliancePercentage}%</td>
                          <td className="py-2 px-3">
                            <span className={`px-2 py-0.2 rounded-full text-[9px] font-extrabold ${
                              c.status === 'green' ? 'bg-emerald-50 text-emerald-800' : c.status === 'yellow' ? 'bg-amber-50 text-amber-800' : 'bg-rose-50 text-rose-800'
                            }`}>{c.status.toUpperCase()}</span>
                          </td>
                          <td className="py-2 px-3">{c.completedBy}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {reportType === 'vaccination' && (
            <div className="space-y-4">
              <h5 className="font-bold text-stone-800 text-xs uppercase tracking-wider">💉 Scheduled & Completed Vaccines</h5>
              {activeVaccinations.length === 0 ? (
                <div className="text-center py-8 text-stone-400 text-xs italic">No matching immunization logs.</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-stone-50 text-stone-500 font-bold border-b border-stone-100">
                        <th className="py-2.5 px-3">Vaccine Name</th>
                        <th className="py-2.5 px-3">Administered On</th>
                        <th className="py-2.5 px-3">Next Booster Due</th>
                        <th className="py-2.5 px-3">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-50 text-stone-700">
                      {activeVaccinations.map(v => (
                        <tr key={v.id}>
                          <td className="py-2 px-3 font-bold">{v.vaccineName}</td>
                          <td className="py-2 px-3 font-mono">{v.scheduleDate}</td>
                          <td className="py-2 px-3 font-mono">{v.nextDueDate}</td>
                          <td className="py-2 px-3 uppercase font-extrabold">{v.status}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {reportType === 'health' && (
            <div className="space-y-4">
              <h5 className="font-bold text-stone-800 text-xs uppercase tracking-wider">🩺 Sickness & Disease Observations</h5>
              {activeHealth.length === 0 ? (
                <div className="text-center py-8 text-stone-400 text-xs italic">No sickness records found.</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-stone-50 text-stone-500 font-bold border-b border-stone-100">
                        <th className="py-2.5 px-3">Disease Diagnosed</th>
                        <th className="py-2.5 px-3">Symptoms Observed</th>
                        <th className="py-2.5 px-3">Prescribed Treatment</th>
                        <th className="py-2.5 px-3">Report Date</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-50 text-stone-700">
                      {activeHealth.map(h => (
                        <tr key={h.id}>
                          <td className="py-2 px-3 font-bold text-rose-800">{h.disease}</td>
                          <td className="py-2 px-3">{h.symptoms}</td>
                          <td className="py-2 px-3 text-emerald-800 font-semibold">{h.treatment}</td>
                          <td className="py-2 px-3">{new Date(h.createdAt).toLocaleDateString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {reportType === 'performance' && (
            <div className="space-y-4">
              <h5 className="font-bold text-stone-800 text-xs uppercase tracking-wider">📈 Husbandry Performance & Consumption Metrics</h5>
              {activeDaily.length === 0 ? (
                <div className="text-center py-8 text-stone-400 text-xs italic">No performance records in this range.</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-stone-50 text-stone-500 font-bold border-b border-stone-100">
                        <th className="py-2.5 px-3">Date</th>
                        <th className="py-2.5 px-3">Feed Intake (kg)</th>
                        <th className="py-2.5 px-3">Water Intake (L)</th>
                        <th className="py-2.5 px-3">Mortality (heads)</th>
                        <th className="py-2.5 px-3">Avg Weight (kg)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-50 text-stone-700">
                      {activeDaily.map(d => (
                        <tr key={d.id}>
                          <td className="py-2 px-3 font-mono font-bold">{d.date}</td>
                          <td className="py-2 px-3">{d.feedConsumption} kg</td>
                          <td className="py-2 px-3">{d.waterConsumption} L</td>
                          <td className="py-2 px-3 font-semibold text-rose-700">{d.mortalityCount}</td>
                          <td className="py-2 px-3">{d.averageWeight} kg</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* Letterhead Footer */}
          <div className="pt-6 border-t border-stone-200 flex justify-between items-center text-[10px] text-stone-400">
            <span>Official digital compliance sheet</span>
            <span className="font-bold">Stamp cleared by Portal Authority</span>
          </div>
        </div>
      )}

    </motion.div>
  );
}
