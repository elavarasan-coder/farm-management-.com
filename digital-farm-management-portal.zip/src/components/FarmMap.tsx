import React, { useState, useEffect, useRef } from 'react';
import { 
  APIProvider, 
  Map, 
  AdvancedMarker, 
  Pin, 
  InfoWindow, 
  useMap, 
  useMapsLibrary 
} from '@vis.gl/react-google-maps';
import { 
  MapPin, 
  Search, 
  Navigation, 
  Info, 
  Compass, 
  Layers, 
  MousePointerClick,
  HelpCircle,
  X
} from 'lucide-react';
import { Farm } from '../types';

interface FarmMapProps {
  farms: Farm[];
  onSelectCoordinates?: (lat: number, lng: number, addressName?: string) => void;
  selectedLat?: number;
  selectedLng?: number;
  interactiveMode?: boolean; // If true, allows clicking to set location
  height?: string;
  defaultZoom?: number;
}

const API_KEY =
  process.env.GOOGLE_MAPS_PLATFORM_KEY ||
  (import.meta as any).env?.VITE_GOOGLE_MAPS_PLATFORM_KEY ||
  (globalThis as any).GOOGLE_MAPS_PLATFORM_KEY ||
  '';
const hasValidKey = Boolean(API_KEY) && API_KEY !== 'YOUR_API_KEY';

// Inner component that needs access to useMap/useMapsLibrary hooks
function MapControls({ 
  farms, 
  onSelectCoordinates, 
  selectedLat, 
  selectedLng, 
  interactiveMode,
  activeFarmId,
  setActiveFarmId
}: {
  farms: Farm[];
  onSelectCoordinates?: (lat: number, lng: number, addressName?: string) => void;
  selectedLat?: number;
  selectedLng?: number;
  interactiveMode?: boolean;
  activeFarmId: string | null;
  setActiveFarmId: (id: string | null) => void;
}) {
  const map = useMap();
  const mapsLibrary = useMapsLibrary('maps');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [mapType, setMapType] = useState<'roadmap' | 'hybrid' | 'terrain'>('roadmap');

  // Handle map type toggle
  useEffect(() => {
    if (!map) return;
    map.setMapTypeId(mapType);
  }, [map, mapType]);

  // Handle clicking on map to place pin (in interactive mode)
  useEffect(() => {
    if (!map || !interactiveMode || !onSelectCoordinates) return;

    const listener = map.addListener('click', (e: google.maps.MapMouseEvent) => {
      const latLng = e.latLng;
      if (latLng) {
        const lat = latLng.lat();
        const lng = latLng.lng();
        
        // Try geocoding to find address name
        const geocoder = new google.maps.Geocoder();
        geocoder.geocode({ location: { lat, lng } }, (results, status) => {
          let addressName = '';
          if (status === 'OK' && results && results[0]) {
            addressName = results[0].formatted_address;
          }
          onSelectCoordinates(lat, lng, addressName);
        });
      }
    });

    return () => {
      google.maps.event.removeListener(listener);
    };
  }, [map, interactiveMode, onSelectCoordinates]);

  // Fly to selected coordinate if it changes
  useEffect(() => {
    if (!map || !selectedLat || !selectedLng) return;
    map.panTo({ lat: selectedLat, lng: selectedLng });
    map.setZoom(15);
  }, [map, selectedLat, selectedLng]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim() || !map) return;

    setSearchLoading(true);
    setSearchError(null);

    const geocoder = new google.maps.Geocoder();
    geocoder.geocode({ address: searchQuery }, (results, status) => {
      setSearchLoading(false);
      if (status === 'OK' && results && results[0]) {
        const loc = results[0].geometry.location;
        map.setCenter(loc);
        map.setZoom(14);
        
        // If in interactive mode, automatically place the pin at the search result center
        if (interactiveMode && onSelectCoordinates) {
          onSelectCoordinates(
            loc.lat(),
            loc.lng(),
            results[0].formatted_address
          );
        }
      } else {
        setSearchError('Address not found. Please try a different query.');
      }
    });
  };

  const handleRecenter = () => {
    if (!map) return;
    if (selectedLat && selectedLng) {
      map.panTo({ lat: selectedLat, lng: selectedLng });
      map.setZoom(15);
    } else if (farms.length > 0) {
      // Average center of all farms
      const validFarms = farms.filter(f => f.latitude && f.longitude);
      if (validFarms.length > 0) {
        const latSum = validFarms.reduce((sum, f) => sum + (f.latitude || 0), 0);
        const lngSum = validFarms.reduce((sum, f) => sum + (f.longitude || 0), 0);
        map.panTo({ lat: latSum / validFarms.length, lng: lngSum / validFarms.length });
        map.setZoom(10);
      } else {
        // Default USA center
        map.panTo({ lat: 39.8283, lng: -98.5795 });
        map.setZoom(4);
      }
    } else {
      // Default fallback
      map.panTo({ lat: 39.8283, lng: -98.5795 });
      map.setZoom(4);
    }
  };

  return (
    <div className="absolute top-4 left-4 right-4 z-10 flex flex-col gap-2 pointer-events-none">
      {/* Top Search Toolbar */}
      <div className="flex gap-2 w-full max-w-md pointer-events-auto">
        <form onSubmit={handleSearch} className="flex-1 flex bg-white/95 dark:bg-stone-900/95 backdrop-blur-md border border-stone-200/50 dark:border-stone-800 rounded-2xl shadow-lg overflow-hidden">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search address or city..."
            className="flex-1 px-4 py-2.5 text-xs focus:outline-none bg-transparent dark:text-stone-100"
          />
          <button
            type="submit"
            disabled={searchLoading}
            className="px-4 hover:bg-emerald-50 dark:hover:bg-stone-800 text-stone-500 hover:text-emerald-700 transition border-l border-stone-100 dark:border-stone-800"
          >
            {searchLoading ? (
              <div className="animate-spin h-4.5 w-4.5 border-2 border-emerald-600 border-t-transparent rounded-full" />
            ) : (
              <Search className="h-4.5 w-4.5" />
            )}
          </button>
        </form>

        {/* Recenter & Map Type Controls */}
        <div className="flex gap-1.5 pointer-events-auto">
          <button
            type="button"
            onClick={handleRecenter}
            className="p-3 bg-white/95 dark:bg-stone-900/95 backdrop-blur-md hover:bg-stone-50 dark:hover:bg-stone-800 border border-stone-200/50 dark:border-stone-800 rounded-2xl shadow-lg text-stone-600 dark:text-stone-300 hover:text-emerald-600 dark:hover:text-emerald-400 transition"
            title="Recenter Map"
          >
            <Navigation className="h-4.5 w-4.5" />
          </button>
          
          <div className="relative group">
            <button
              type="button"
              className="p-3 bg-white/95 dark:bg-stone-900/95 backdrop-blur-md hover:bg-stone-50 dark:hover:bg-stone-800 border border-stone-200/50 dark:border-stone-800 rounded-2xl shadow-lg text-stone-600 dark:text-stone-300 transition flex items-center gap-1.5"
              title="Map Layer"
            >
              <Layers className="h-4.5 w-4.5" />
            </button>
            <div className="absolute right-0 mt-1.5 w-36 bg-white dark:bg-stone-900 border border-stone-200/50 dark:border-stone-800 shadow-xl rounded-xl p-2 hidden group-hover:block z-20">
              <button
                type="button"
                onClick={() => setMapType('roadmap')}
                className={`w-full text-left px-3 py-1.5 text-[11px] font-bold rounded-lg transition ${mapType === 'roadmap' ? 'bg-emerald-50 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400' : 'text-stone-600 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-850'}`}
              >
                🗺️ Standard
              </button>
              <button
                type="button"
                onClick={() => setMapType('hybrid')}
                className={`w-full text-left px-3 py-1.5 text-[11px] font-bold rounded-lg transition ${mapType === 'hybrid' ? 'bg-emerald-50 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400' : 'text-stone-600 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-850'}`}
              >
                🛰️ Satellite
              </button>
              <button
                type="button"
                onClick={() => setMapType('terrain')}
                className={`w-full text-left px-3 py-1.5 text-[11px] font-bold rounded-lg transition ${mapType === 'terrain' ? 'bg-emerald-50 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400' : 'text-stone-600 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-850'}`}
              >
                ⛰️ Terrain
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Error Toast */}
      {searchError && (
        <div className="bg-rose-50/95 dark:bg-rose-950/90 backdrop-blur-sm border border-rose-100 dark:border-rose-900 text-rose-800 dark:text-rose-200 text-[11px] font-bold px-4 py-2.5 rounded-2xl shadow-md w-full max-w-md pointer-events-auto flex justify-between items-center">
          <span>{searchError}</span>
          <button onClick={() => setSearchError(null)} className="text-rose-500 hover:text-rose-700">
            <X className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* Interactive Helper Banner */}
      {interactiveMode && (
        <div className="bg-emerald-900/90 dark:bg-stone-900/90 text-white backdrop-blur-md border border-emerald-800/40 px-4 py-2.5 rounded-2xl shadow-lg w-full max-w-md pointer-events-auto flex items-center gap-2.5">
          <MousePointerClick className="h-4 w-4 text-emerald-400 shrink-0" />
          <p className="text-[10px] leading-relaxed font-semibold">
            Click anywhere on the map to set your farm location, or search for an address. You can drag the pin once dropped!
          </p>
        </div>
      )}
    </div>
  );
}

export default function FarmMap({ 
  farms, 
  onSelectCoordinates, 
  selectedLat, 
  selectedLng, 
  interactiveMode = false,
  height = '350px',
  defaultZoom
}: FarmMapProps) {

  const [activeFarmId, setActiveFarmId] = useState<string | null>(null);

  // If key is missing, show beautiful instructions block so user knows exactly what to do
  if (!hasValidKey) {
    return (
      <div 
        style={{ height }}
        className="w-full bg-[#fbfcfb] dark:bg-stone-900 border border-stone-200/50 dark:border-stone-800 rounded-3xl p-6 sm:p-8 flex flex-col items-center justify-center text-center shadow-sm relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 p-8 opacity-5">
          <MapPin className="h-44 w-44" />
        </div>
        
        <div className="max-w-md space-y-4 z-10">
          <div className="mx-auto h-12 w-12 bg-emerald-50 dark:bg-stone-850 rounded-2xl flex items-center justify-center text-emerald-600 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-800/60 shadow-sm">
            <Compass className="h-6 w-6 animate-spin" style={{ animationDuration: '6s' }} />
          </div>
          
          <div className="space-y-1.5">
            <h3 className="text-stone-900 dark:text-stone-50 font-extrabold text-base tracking-tight">
              Google Maps API Key Required
            </h3>
            <p className="text-stone-500 dark:text-stone-400 text-xs leading-relaxed font-medium">
              To plot facilities, register land boundaries, and unlock geographical biosecurity zoning, configure your API key securely.
            </p>
          </div>

          <div className="bg-white dark:bg-stone-850 border border-stone-200/40 dark:border-stone-700/50 rounded-2xl p-4.5 text-left text-xs space-y-3 shadow-inner">
            <div className="flex gap-2.5 items-start">
              <span className="h-5 w-5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px] flex items-center justify-center shrink-0">1</span>
              <p className="text-stone-600 dark:text-stone-300 font-medium">
                Get an API key from the{' '}
                <a 
                  href="https://console.cloud.google.com/google/maps-apis/start?utm_campaign=gmp-code-assist-ais" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-emerald-700 dark:text-emerald-400 font-extrabold hover:underline"
                >
                  Google Cloud Console
                </a>.
              </p>
            </div>
            <div className="flex gap-2.5 items-start">
              <span className="h-5 w-5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px] flex items-center justify-center shrink-0">2</span>
              <p className="text-stone-600 dark:text-stone-300 font-medium">
                Add your key to Secrets: click the <strong>Settings (⚙️ gear icon, top-right)</strong>, go to <strong>Secrets</strong>, and add <code>GOOGLE_MAPS_PLATFORM_KEY</code>.
              </p>
            </div>
            <div className="flex gap-2.5 items-start">
              <span className="h-5 w-5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px] flex items-center justify-center shrink-0">3</span>
              <p className="text-stone-500 dark:text-stone-400 text-[11px] leading-normal font-semibold">
                The portal will instantly compile your build on key entry. No page reloads needed!
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Calculate default map configuration
  const validFarms = farms.filter(f => f.latitude && f.longitude);
  const mapCenter = selectedLat && selectedLng 
    ? { lat: selectedLat, lng: selectedLng }
    : validFarms.length > 0
    ? { lat: validFarms[0].latitude!, lng: validFarms[0].longitude! }
    : { lat: 39.8283, lng: -98.5795 }; // Center of USA

  const zoomLevel = defaultZoom || (selectedLat && selectedLng ? 15 : validFarms.length > 0 ? 9 : 4);

  return (
    <div 
      style={{ height }} 
      className="w-full rounded-3xl overflow-hidden border border-stone-200/50 dark:border-stone-800 shadow-sm relative"
    >
      <APIProvider apiKey={API_KEY} version="weekly">
        <Map
          defaultCenter={mapCenter}
          defaultZoom={zoomLevel}
          mapId="DEMO_MAP_ID"
          internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
          style={{ width: '100%', height: '100%' }}
          gestureHandling="greedy"
          disableDefaultUI={false}
        >
          {/* Active controls overlay */}
          <MapControls 
            farms={farms} 
            onSelectCoordinates={onSelectCoordinates}
            selectedLat={selectedLat}
            selectedLng={selectedLng}
            interactiveMode={interactiveMode}
            activeFarmId={activeFarmId}
            setActiveFarmId={setActiveFarmId}
          />

          {/* Render markers for all farms */}
          {!interactiveMode && validFarms.map((farm) => {
            const isPig = farm.farmType === 'Pig';
            return (
              <AdvancedMarker
                key={farm.id}
                position={{ lat: farm.latitude!, lng: farm.longitude! }}
                onClick={() => setActiveFarmId(farm.id)}
              >
                <Pin 
                  background={isPig ? '#10b981' : '#f59e0b'} 
                  borderColor="#ffffff" 
                  glyph={isPig ? '🐷' : '🐔'}
                />
              </AdvancedMarker>
            );
          })}

          {/* Render draggable pin in interactive / selection mode */}
          {interactiveMode && selectedLat && selectedLng && (
            <AdvancedMarker
              position={{ lat: selectedLat, lng: selectedLng }}
              draggable={true}
              onDragEnd={(e) => {
                if (e.latLng && onSelectCoordinates) {
                  const lat = e.latLng.lat();
                  const lng = e.latLng.lng();
                  
                  // Geocode location address name
                  const geocoder = new google.maps.Geocoder();
                  geocoder.geocode({ location: { lat, lng } }, (results, status) => {
                    let addressName = '';
                    if (status === 'OK' && results && results[0]) {
                      addressName = results[0].formatted_address;
                    }
                    onSelectCoordinates(lat, lng, addressName);
                  });
                }
              }}
            >
              <Pin background="#ef4444" borderColor="#ffffff" glyph="📍" />
            </AdvancedMarker>
          )}

          {/* InfoWindow for clicked farm */}
          {!interactiveMode && activeFarmId && (
            (() => {
              const activeFarm = farms.find(f => f.id === activeFarmId);
              if (!activeFarm || !activeFarm.latitude || !activeFarm.longitude) return null;
              
              const isPig = activeFarm.farmType === 'Pig';
              
              return (
                <InfoWindow
                  position={{ lat: activeFarm.latitude, lng: activeFarm.longitude }}
                  onCloseClick={() => setActiveFarmId(null)}
                >
                  <div className="p-1 max-w-[200px] text-stone-900 text-xs">
                    <div className="flex items-center gap-1.5 mb-1">
                      <span className="text-sm">{isPig ? '🐷' : '🐔'}</span>
                      <strong className="font-extrabold text-stone-900 leading-tight">{activeFarm.name}</strong>
                    </div>
                    <p className="text-[10px] text-stone-500 mb-1.5">{activeFarm.location}</p>
                    <div className="flex justify-between items-center border-t border-stone-150 pt-1.5 text-[10px] text-stone-700 font-semibold">
                      <span>Headcount:</span>
                      <span className="font-extrabold text-emerald-800 font-mono">{activeFarm.animalCount.toLocaleString()}</span>
                    </div>
                  </div>
                </InfoWindow>
              );
            })()
          )}
        </Map>
      </APIProvider>
    </div>
  );
}
