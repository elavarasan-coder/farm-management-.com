import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  User, Shield, Moon, Sun, Globe, Database, LogOut, 
  CheckCircle2, Sparkles, HelpCircle 
} from 'lucide-react';
import { Role } from '../types';

interface SettingsProps {
  displayName: string;
  role: Role;
  onUpdateProfile: (name: string, role: Role) => void;
  onLogOut: () => void;
  onSeedDemoData: () => Promise<void>;
  darkMode: boolean;
  onToggleDarkMode: () => void;
}

export default function Settings({ 
  displayName, 
  role, 
  onUpdateProfile, 
  onLogOut, 
  onSeedDemoData,
  darkMode,
  onToggleDarkMode
}: SettingsProps) {

  const [name, setName] = useState(displayName);
  const [selectedRole, setSelectedRole] = useState<Role>(role);
  
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [language, setLanguage] = useState('en');

  const [toast, setToast] = useState<string | null>(null);
  const [seeding, setSeeding] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onUpdateProfile(name.trim(), selectedRole);
    setToast('Profile metadata updated successfully.');
    setTimeout(() => setToast(null), 3000);
  };

  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!password) return;
    if (password !== confirmPassword) {
      alert('Passwords do not match.');
      return;
    }
    setPassword('');
    setConfirmPassword('');
    setToast('Secure password changed (simulated successfully).');
    setTimeout(() => setToast(null), 3000);
  };

  const handleSeed = async () => {
    setSeeding(true);
    try {
      await onSeedDemoData();
      setToast('Success! Live Firebase Firestore database has been seeded with historical records.');
      setTimeout(() => setToast(null), 4000);
    } catch (err: any) {
      alert(err.message || 'Failed to seed demo database.');
    } finally {
      setSeeding(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="max-w-4xl mx-auto space-y-8"
    >
      <div>
        <h2 className="text-2xl font-extrabold text-stone-900 tracking-tight">System Settings</h2>
        <p className="text-stone-500 text-sm">Configure farm permissions, profiles, database backups, and interface selections</p>
      </div>

      {toast && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs px-4 py-3 rounded-xl flex items-center gap-2 font-bold shadow-sm">
          <CheckCircle2 className="h-4.5 w-4.5 text-emerald-600 shrink-0" />
          <span>{toast}</span>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* PROFILE MANAGEMENT SECTION */}
        <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-4">
          <h4 className="font-extrabold text-stone-900 text-base flex items-center gap-2 pb-2 border-b border-stone-100">
            <User className="h-5 w-5 text-emerald-600" />
            Profile Management
          </h4>

          <form onSubmit={handleSaveProfile} className="space-y-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-stone-700 block">User Display Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs focus:ring-emerald-500 focus:outline-none focus:ring-2"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-stone-700 block">Authorized System Role</label>
              <select
                value={selectedRole}
                onChange={(e) => setSelectedRole(e.target.value as Role)}
                className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs focus:ring-emerald-500 focus:outline-none focus:ring-2 font-bold text-stone-800"
              >
                <option value="Farmer">Farmer (Full Logs)</option>
                <option value="Farm Manager">Farm Manager (Compliance Focus)</option>
                <option value="Administrator">Administrator (Global Access)</option>
              </select>
            </div>

            <button
              type="submit"
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg transition shadow-sm cursor-pointer"
            >
              Update Profile Details
            </button>
          </form>
        </div>

        {/* SECURITY & CHANGE PASSWORD */}
        <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-4">
          <h4 className="font-extrabold text-stone-900 text-base flex items-center gap-2 pb-2 border-b border-stone-100">
            <Shield className="h-5 w-5 text-emerald-600" />
            Security & Credentials
          </h4>

          <form onSubmit={handleChangePassword} className="space-y-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-stone-700 block">New Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs focus:ring-emerald-500 focus:outline-none focus:ring-2"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-stone-700 block">Confirm New Password</label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs focus:ring-emerald-500 focus:outline-none focus:ring-2"
                required
              />
            </div>

            <button
              type="submit"
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg transition shadow-sm cursor-pointer"
            >
              Update Password Key
            </button>
          </form>
        </div>

        {/* INTERFACE CONFIG (DARK MODE & LANGUAGE) */}
        <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-6">
          <h4 className="font-extrabold text-stone-900 text-base flex items-center gap-2 pb-2 border-b border-stone-100">
            <Globe className="h-5 w-5 text-emerald-600" />
            Preferences & Language
          </h4>

          {/* Theme setting */}
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <span className="text-xs font-bold text-stone-800 block">Visual Interface Theme</span>
              <span className="text-[10px] text-stone-500">Toggle dark mode or light agricultural theme</span>
            </div>
            <button
              onClick={onToggleDarkMode}
              className="p-2 border border-stone-200 rounded-xl hover:bg-stone-50 transition cursor-pointer"
            >
              {darkMode ? (
                <div className="flex items-center gap-1.5 text-xs font-bold text-amber-500">
                  <Sun className="h-4.5 w-4.5" />
                  <span>Light Mode</span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 text-xs font-bold text-stone-600">
                  <Moon className="h-4.5 w-4.5" />
                  <span>Dark Mode</span>
                </div>
              )}
            </button>
          </div>

          {/* Language Selection */}
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <span className="text-xs font-bold text-stone-800 block">System Language</span>
              <span className="text-[10px] text-stone-500">Localize reports and checklists</span>
            </div>
            <select
              value={language}
              onChange={(e) => {
                setLanguage(e.target.value);
                setToast('Language preference updated.');
                setTimeout(() => setToast(null), 3000);
              }}
              className="px-3 py-1.5 border border-stone-200 rounded-lg text-xs font-bold text-stone-700 bg-white"
            >
              <option value="en">🇺🇸 English</option>
              <option value="es">🇪🇸 Español</option>
              <option value="vi">🇻🇳 Tiếng Việt</option>
              <option value="th">🇹🇭 ไทย</option>
            </select>
          </div>
        </div>

        {/* DATABASE BACKUP & INSTANT SEEDER */}
        <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-4">
          <h4 className="font-extrabold text-stone-900 text-base flex items-center gap-2 pb-2 border-b border-stone-100">
            <Database className="h-5 w-5 text-emerald-600" />
            Data Backups & Seeding
          </h4>

          <div className="space-y-3.5">
            <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-100 text-xs text-stone-600 leading-relaxed space-y-1">
              <div className="flex items-center gap-1.5 text-emerald-900 font-bold mb-1">
                <Sparkles className="h-4 w-4" />
                <span>Presentation Seeding</span>
              </div>
              <p>
                To immediately display fully loaded Recharts graphs, visitor registers, biosecurity checklists, vaccination reminders, and health alerts, click below to seed your live Firestore with comprehensive, realistic pig and poultry farm datasets.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <button
                type="button"
                onClick={handleSeed}
                disabled={seeding}
                className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center gap-1 transition shadow-sm cursor-pointer text-center justify-center shrink-0"
              >
                <Database className="h-4 w-4 shrink-0" />
                {seeding ? 'Seeding Firestore...' : 'Seed Live Mock Datasets'}
              </button>
              
              <button
                type="button"
                onClick={() => {
                  setToast('Database backup archive generated successfully (Downloaded to device)');
                  setTimeout(() => setToast(null), 3000);
                }}
                className="px-4 py-2.5 border border-stone-200 hover:bg-stone-50 text-stone-700 font-bold text-xs rounded-xl transition text-center justify-center cursor-pointer"
              >
                Download CSV Backup
              </button>
            </div>
          </div>
        </div>

      </div>

      {/* FOOTER ACTIONS */}
      <div className="flex justify-end pt-4 border-t border-stone-200">
        <button
          onClick={onLogOut}
          className="flex items-center gap-1.5 bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 font-extrabold text-xs px-5 py-3 rounded-xl transition cursor-pointer"
        >
          <LogOut className="h-4.5 w-4.5" />
          Log Out of Session
        </button>
      </div>

    </motion.div>
  );
}
