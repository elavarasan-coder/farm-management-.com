import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Syringe, Plus, Calendar, ShieldCheck, Clock, ShieldAlert, Check } from 'lucide-react';
import { Farm, Vaccination, Role } from '../types';

interface VaccinationProps {
  farms: Farm[];
  vaccinations: Vaccination[];
  role: Role;
  onAddVaccination: (vacc: Omit<Vaccination, 'id' | 'recordedBy' | 'createdAt'>) => Promise<void>;
  onMarkVaccinated: (farmId: string, id: string) => Promise<void>;
}

export default function VaccinationHub({ 
  farms, 
  vaccinations, 
  role,
  onAddVaccination, 
  onMarkVaccinated 
}: VaccinationProps) {

  const [selectedFarmId, setSelectedFarmId] = useState<string>(farms[0]?.id || '');
  const [vaccineName, setVaccineName] = useState('');
  const [scheduleDate, setScheduleDate] = useState(new Date().toISOString().split('T')[0]);
  const [nextDueDate, setNextDueDate] = useState('');
  const [notes, setNotes] = useState('');

  const [loading, setLoading] = useState(false);
  const [isAdding, setIsAdding] = useState(false);

  // Filter vaccinations for selected farm
  const activeVaccinations = vaccinations.filter(v => v.farmId === selectedFarmId);

  // Separate schedules
  const completedVaccines = activeVaccinations.filter(v => v.status === 'completed');
  const pendingVaccines = activeVaccinations.filter(v => v.status === 'scheduled' || v.status === 'overdue');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFarmId) {
      alert('Please select a farm first.');
      return;
    }
    if (!vaccineName.trim() || !scheduleDate) {
      alert('Vaccine Name and Schedule Date are required.');
      return;
    }

    // Set fallback next due date if empty (e.g. 1 month from schedule date)
    const finalNextDueDate = nextDueDate || new Date(new Date(scheduleDate).setMonth(new Date(scheduleDate).getMonth() + 1)).toISOString().split('T')[0];

    // Determine status: if due date is in the past, it could be overdue, but usually default to scheduled
    const statusVal = new Date(finalNextDueDate) < new Date() ? 'overdue' : 'scheduled';

    setLoading(true);
    try {
      await onAddVaccination({
        farmId: selectedFarmId,
        vaccineName: vaccineName.trim(),
        scheduleDate,
        nextDueDate: finalNextDueDate,
        status: statusVal,
        notes: notes.trim()
      });

      // Reset
      setVaccineName('');
      setNotes('');
      setNextDueDate('');
      setIsAdding(false);
    } catch (err: any) {
      alert(err.message || 'Failed to add vaccination schedule.');
    } finally {
      setLoading(false);
    }
  };

  const handleComplete = async (vaccId: string) => {
    setLoading(true);
    try {
      await onMarkVaccinated(selectedFarmId, vaccId);
    } catch (err: any) {
      alert(err.message || 'Failed to record completion.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-6"
    >
      {/* Selector Header */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm flex flex-col sm:flex-row justify-between items-center gap-4">
        <div className="flex items-center gap-3">
          <Syringe className="h-6 w-6 text-emerald-600 shrink-0" />
          <div>
            <h3 className="font-extrabold text-stone-900 text-sm sm:text-base">Vaccination & Immunisation Hub</h3>
            <p className="text-stone-500 text-xs">Schedule veterinary doses, review medical schedules, and prevent swine/fowl diseases</p>
          </div>
        </div>
        <div className="w-full sm:w-auto flex gap-2">
          <select
            value={selectedFarmId}
            onChange={(e) => setSelectedFarmId(e.target.value)}
            className="w-full sm:w-64 px-3 py-2 border border-stone-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold bg-stone-50"
          >
            {farms.length === 0 ? (
              <option value="">No registered farms found</option>
            ) : (
              farms.map(f => (
                <option key={f.id} value={f.id}>
                  {f.name} ({f.farmType})
                </option>
              ))
            )}
          </select>
          {farms.length > 0 && !isAdding && (
            <button
              onClick={() => setIsAdding(true)}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl flex items-center gap-1 shrink-0 transition shadow-sm cursor-pointer"
            >
              <Plus className="h-4 w-4" />
              Schedule Vaccine
            </button>
          )}
        </div>
      </div>

      {farms.length === 0 ? (
        <div className="text-center py-16 bg-white border border-stone-200 rounded-2xl">
          <ShieldAlert className="h-12 w-12 text-stone-300 mx-auto mb-3" />
          <p className="font-bold text-stone-700">Please Register a Farm Unit First</p>
          <p className="text-stone-500 text-xs mt-1">Configure a farm first to record active vaccination calendars.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* SCHEDULING FORM CARD */}
          {isAdding && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white p-6 rounded-2xl border border-stone-200 shadow-md space-y-4 h-fit"
            >
              <div className="flex justify-between items-center pb-2 border-b border-stone-100">
                <h4 className="font-bold text-stone-900 text-sm flex items-center gap-1">
                  <Plus className="h-4 w-4 text-emerald-600" />
                  New Vaccination Plan
                </h4>
                <button 
                  onClick={() => setIsAdding(false)}
                  className="text-stone-400 hover:text-stone-600 text-xs font-bold"
                >
                  Close
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-700 block">Vaccine Name</label>
                  <input
                    type="text"
                    value={vaccineName}
                    onChange={(e) => setVaccineName(e.target.value)}
                    placeholder="e.g. Parvovirus Dose 1"
                    className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs focus:ring-emerald-500 focus:outline-none focus:ring-2"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-700 block">Schedule Date (Administered)</label>
                  <input
                    type="date"
                    value={scheduleDate}
                    onChange={(e) => setScheduleDate(e.target.value)}
                    className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs focus:ring-emerald-500 focus:outline-none focus:ring-2"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-700 block">Next Due Date (Booster)</label>
                  <input
                    type="date"
                    value={nextDueDate}
                    onChange={(e) => setNextDueDate(e.target.value)}
                    className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs focus:ring-emerald-500 focus:outline-none focus:ring-2"
                    placeholder="Leave empty for auto 30-day interval"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-700 block">Shedding Notes & Dosage</label>
                  <textarea
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="e.g. Inject 2ml intramusculary. Keep feed isolated for 6 hours."
                    className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs focus:ring-emerald-500 focus:outline-none focus:ring-2 h-16 resize-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-sm transition uppercase tracking-wide cursor-pointer"
                >
                  {loading ? 'Creating...' : 'Log Schedule'}
                </button>
              </form>
            </motion.div>
          )}

          {/* VACCINATIONS TRACKING GRID */}
          <div className={`${isAdding ? 'lg:col-span-2' : 'lg:col-span-3'} space-y-6`}>
            
            {/* Scheduled boosters */}
            <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
              <h4 className="font-extrabold text-stone-900 text-base mb-3 flex items-center gap-2">
                <Clock className="h-5 w-5 text-amber-500" />
                Boosters & Pending Doses
              </h4>

              {pendingVaccines.length === 0 ? (
                <div className="text-center py-8 text-stone-400 text-xs">
                  Zero pending schedules for this farm. Add a vaccine to trigger calendar notifications.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {pendingVaccines.map((vacc) => {
                    const isOverdue = vacc.status === 'overdue' || new Date(vacc.nextDueDate) < new Date();
                    return (
                      <div 
                        key={vacc.id}
                        className={`p-4 border rounded-2xl flex justify-between items-start gap-4 transition bg-stone-50/50 ${
                          isOverdue ? 'border-rose-200 ring-2 ring-rose-50' : 'border-stone-150'
                        }`}
                      >
                        <div className="space-y-2 flex-grow">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-extrabold text-stone-900 text-xs">{vacc.vaccineName}</span>
                            <span className={`px-2 py-0.2 rounded-full text-[8px] font-extrabold tracking-wide uppercase ${
                              isOverdue ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'
                            }`}>
                              {isOverdue ? 'OVERDUE' : 'SCHEDULED'}
                            </span>
                          </div>
                          
                          <p className="text-[10px] text-stone-500 leading-normal">
                            <strong className="text-stone-700">Dose Administered:</strong> {new Date(vacc.scheduleDate).toLocaleDateString()}
                          </p>
                          {vacc.notes && (
                            <p className="text-[10px] text-stone-500 italic bg-white p-1.5 border border-stone-100 rounded leading-normal">
                              {vacc.notes}
                            </p>
                          )}

                          <div className="text-[9px] text-stone-400 font-mono">
                            Scheduled by: {vacc.recordedBy}
                          </div>
                        </div>

                        <div className="text-right shrink-0 flex flex-col justify-between h-full space-y-4">
                          <div>
                            <span className="text-[8px] uppercase tracking-wider font-bold text-stone-400 block">BOOSTER DUE</span>
                            <span className={`text-xs font-mono font-extrabold ${isOverdue ? 'text-rose-600' : 'text-stone-700'}`}>
                              {new Date(vacc.nextDueDate).toLocaleDateString()}
                            </span>
                          </div>

                          <button
                            onClick={() => handleComplete(vacc.id)}
                            disabled={loading}
                            className="bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold border border-emerald-200 rounded-lg px-2.5 py-1 text-[10px] flex items-center gap-1 shadow-sm shrink-0 transition"
                            title="Mark dosage as completed"
                          >
                            <Check className="h-3 w-3 text-emerald-600" />
                            Administer
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Historical completed record */}
            <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
              <h4 className="font-extrabold text-stone-900 text-base mb-3 flex items-center gap-2">
                <ShieldCheck className="h-5 w-5 text-emerald-600" />
                Completed Immunisation Logs
              </h4>

              {completedVaccines.length === 0 ? (
                <div className="text-center py-6 text-stone-400 text-xs">
                  No completed vaccination logs found. Mark scheduled vaccines as completed to save to history.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-stone-50 text-stone-500 font-bold uppercase tracking-wider text-[10px] border-b border-stone-100">
                        <th className="py-3 px-4">Vaccine Name</th>
                        <th className="py-3 px-4">Administered On</th>
                        <th className="py-3 px-4">Next Booster</th>
                        <th className="py-3 px-4">Notes</th>
                        <th className="py-3 px-4">Logged By</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-50">
                      {completedVaccines.slice().reverse().map((v) => (
                        <tr key={v.id} className="hover:bg-stone-50/50">
                          <td className="py-3 px-4 font-bold text-stone-900">{v.vaccineName}</td>
                          <td className="py-3 px-4 font-mono text-stone-600">{new Date(v.scheduleDate).toLocaleDateString()}</td>
                          <td className="py-3 px-4 font-mono text-stone-500">{new Date(v.nextDueDate).toLocaleDateString()}</td>
                          <td className="py-3 px-4 text-stone-500 italic max-w-xs truncate" title={v.notes}>{v.notes || '-'}</td>
                          <td className="py-3 px-4 text-stone-500 font-medium">{v.recordedBy}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

          </div>

        </div>
      )}

    </motion.div>
  );
}
