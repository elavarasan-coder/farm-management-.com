import React from 'react';
import { motion } from 'motion/react';
import { 
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid, 
  PieChart, Pie, Cell 
} from 'recharts';
import { 
  Sprout, Shield, ShieldCheck, ShieldAlert, Syringe, 
  TrendingUp, Activity, ClipboardList, PlusCircle, ArrowRight, Clock
} from 'lucide-react';
import { Farm, BiosecurityChecklist, Vaccination, HealthRecord, Role } from '../types';

interface DashboardProps {
  farms: Farm[];
  checklists: BiosecurityChecklist[];
  vaccinations: Vaccination[];
  healthRecords: HealthRecord[];
  role: Role;
  onNavigate: (tab: string) => void;
}

export default function Dashboard({ 
  farms, 
  checklists, 
  vaccinations, 
  healthRecords, 
  role,
  onNavigate 
}: DashboardProps) {
  
  // Calculate Totals
  const totalFarms = farms.length;
  const totalPigs = farms.filter(f => f.farmType === 'Pig').reduce((sum, f) => sum + f.animalCount, 0);
  const totalPoultry = farms.filter(f => f.farmType === 'Poultry').reduce((sum, f) => sum + f.animalCount, 0);
  
  // Compliance average
  const complianceAvg = checklists.length > 0 
    ? Math.round(checklists.reduce((sum, c) => sum + c.compliancePercentage, 0) / checklists.length)
    : 85; // Default display score if empty

  // Vaccination alerts (upcoming or overdue)
  const pendingVaccines = vaccinations.filter(v => v.status === 'scheduled' || v.status === 'overdue');
  
  // Disease and outbreak alerts
  const activeDiseaseAlerts = healthRecords.slice(0, 3);

  // Recharts Data preparation
  const complianceData = checklists.length > 0
    ? checklists.slice(-7).map(c => ({
        date: c.date,
        compliance: c.compliancePercentage
      })).sort((a, b) => a.date.localeCompare(b.date))
    : [
        { date: '06/29', compliance: 75 },
        { date: '06/30', compliance: 80 },
        { date: '07/01', compliance: 90 },
        { date: '07/02', compliance: 85 },
        { date: '07/03', compliance: 95 },
        { date: '07/04', compliance: 90 },
        { date: '07/05', compliance: 100 }
      ];

  const distributionData = [
    { name: 'Pigs', value: totalPigs || 340, color: '#10b981' }, // emerald-500
    { name: 'Poultry', value: totalPoultry || 1250, color: '#f59e0b' } // amber-500
  ];

  // Dynamic system time for display
  const currentSystemTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const currentSystemDate = new Date().toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });

  return (
    <motion.div 
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-6 max-w-7xl mx-auto"
    >
      {/* Dynamic Bento Grid Container */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 auto-rows-max">
        
        {/* CARD 1: HERO PORTAL BANNER (Spans 3 cols on xl, 2 cols on lg/md) */}
        <div className="bg-emerald-950 text-white rounded-[2rem] p-8 md:col-span-2 lg:col-span-2 xl:col-span-3 overflow-hidden relative border border-emerald-900 shadow-sm flex flex-col justify-between min-h-[240px] hover:shadow-md transition-all duration-300">
          
          {/* Glowing artistic ambient circles for Bento styling */}
          <div className="absolute -top-12 -right-12 h-44 w-44 rounded-full bg-emerald-800/30 blur-3xl pointer-events-none"></div>
          <div className="absolute -bottom-16 -left-16 h-48 w-48 rounded-full bg-emerald-700/20 blur-3xl pointer-events-none"></div>

          <div className="relative z-10 flex flex-col sm:flex-row justify-between items-start gap-4">
            <div className="space-y-2">
              <span className="px-3 py-1 bg-emerald-800/50 rounded-full text-[10px] font-mono tracking-widest uppercase font-bold text-emerald-300 border border-emerald-700/30">
                ACTIVE BIOSECURITY PORTAL
              </span>
              <h1 className="text-3xl font-extrabold tracking-tight text-white mt-1">
                Portal Operations
              </h1>
              <p className="text-emerald-100/80 max-w-xl text-xs sm:text-sm font-medium leading-relaxed">
                Seamlessly monitor sanitation protocols, log active animal stocks, schedule veterinary vaccines, and maintain 100% compliant swine & poultry farm safety.
              </p>
            </div>

            {/* Time Capsule */}
            <div className="bg-emerald-900/60 backdrop-blur-sm px-4 py-3 rounded-2xl border border-emerald-800/40 flex items-center gap-2.5 shrink-0 self-stretch sm:self-auto justify-center sm:justify-start">
              <Clock className="h-4 w-4 text-emerald-400" />
              <div className="text-left">
                <span className="text-xs font-bold block leading-none font-mono text-emerald-50">{currentSystemTime}</span>
                <span className="text-[9px] text-emerald-300 block font-medium mt-0.5">{currentSystemDate}</span>
              </div>
            </div>
          </div>

          <div className="relative z-10 pt-6 flex flex-wrap gap-3 items-center justify-between border-t border-emerald-900/40 mt-4">
            <div className="flex items-center gap-3">
              <div className="h-2.5 w-2.5 rounded-full bg-emerald-400 animate-pulse"></div>
              <span className="text-xs font-mono text-emerald-300">
                Logged in: <strong className="text-white font-bold">{role}</strong>
              </span>
            </div>
            <button 
              onClick={() => onNavigate('biosecurity')}
              className="px-4 py-2 bg-white text-emerald-950 hover:bg-emerald-100 text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer"
            >
              Run Audit Checklist
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>

        {/* CARD 2: COMPLIANCE GAUGER BENTO (Col-span 1) */}
        <div className="bg-white dark:bg-stone-900 p-8 rounded-[2rem] border border-stone-200/50 dark:border-stone-800 shadow-sm flex flex-col justify-between min-h-[240px] hover:border-emerald-300 dark:hover:border-emerald-950 hover:shadow-md transition-all duration-300 relative group">
          <div className="flex justify-between items-start">
            <div className="space-y-1">
              <span className="text-stone-400 dark:text-stone-500 text-[10px] font-bold uppercase tracking-wider block">Biosecurity</span>
              <h3 className="text-sm font-extrabold text-stone-900 dark:text-stone-100">Compliance Rate</h3>
            </div>
            <div className={`p-3 rounded-2xl ${
              complianceAvg >= 90 
                ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400' 
                : complianceAvg >= 75 
                ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-500 dark:text-amber-400' 
                : 'bg-rose-50 dark:bg-rose-950/40 text-rose-600'
            }`}>
              <ShieldCheck className="h-5 w-5" />
            </div>
          </div>

          <div className="py-2 flex items-baseline gap-2">
            <span className={`text-6xl font-black tracking-tighter ${
              complianceAvg >= 90 ? 'text-emerald-600 dark:text-emerald-400' : complianceAvg >= 75 ? 'text-amber-500' : 'text-rose-600'
            }`}>
              {complianceAvg}%
            </span>
            <span className="text-stone-400 font-mono text-[10px] font-medium">AVG SCORE</span>
          </div>

          <div className="border-t border-stone-100 dark:border-stone-800 pt-3">
            <div className="flex items-center gap-2">
              <span className={`h-2.5 w-2.5 rounded-full ${
                complianceAvg >= 90 ? 'bg-emerald-500' : complianceAvg >= 75 ? 'bg-amber-500' : 'bg-rose-500'
              }`}></span>
              <span className="text-stone-600 dark:text-stone-400 text-xs font-semibold">
                {complianceAvg >= 90 ? 'High Compliance' : complianceAvg >= 75 ? 'Sanitary Warning' : 'Critical Hazard Alert'}
              </span>
            </div>
          </div>
        </div>

        {/* CARD 3: TOTAL FARMS KPI */}
        <div className="bg-white dark:bg-stone-900 p-6 rounded-[2rem] border border-stone-200/50 dark:border-stone-800 shadow-sm flex flex-col justify-between min-h-[180px] hover:border-emerald-200 dark:hover:border-stone-800 hover:shadow-md transition-all duration-300">
          <div className="flex justify-between items-start">
            <span className="text-stone-400 dark:text-stone-500 text-[10px] font-bold uppercase tracking-wider block">Farms Directory</span>
            <div className="p-2.5 bg-emerald-50 dark:bg-stone-800 text-emerald-600 dark:text-emerald-400 rounded-xl">
              <Sprout className="h-4 w-4" />
            </div>
          </div>
          <div>
            <span className="text-4xl font-extrabold text-stone-900 dark:text-stone-100 tracking-tight block">
              {totalFarms}
            </span>
            <span className="text-stone-500 dark:text-stone-400 text-xs font-medium block mt-1">
              Active facilities registered
            </span>
          </div>
          <button 
            onClick={() => onNavigate('farms')}
            className="text-[10px] font-bold text-emerald-700 dark:text-emerald-400 flex items-center gap-1 cursor-pointer hover:underline self-start pt-1"
          >
            Manage facilities
            <ArrowRight className="h-3 w-3" />
          </button>
        </div>

        {/* CARD 4: TOTAL PIGS LIVESTOCK */}
        <div className="bg-white dark:bg-stone-900 p-6 rounded-[2rem] border border-stone-200/50 dark:border-stone-800 shadow-sm flex flex-col justify-between min-h-[180px] hover:border-emerald-200 dark:hover:border-stone-800 hover:shadow-md transition-all duration-300">
          <div className="flex justify-between items-start">
            <span className="text-stone-400 dark:text-stone-500 text-[10px] font-bold uppercase tracking-wider block">Swine Livestock</span>
            <div className="h-8 w-8 bg-emerald-50 dark:bg-stone-800 text-sm flex items-center justify-center rounded-xl select-none">
              🐷
            </div>
          </div>
          <div>
            <span className="text-4xl font-extrabold text-stone-900 dark:text-stone-100 tracking-tight block">
              {totalPigs.toLocaleString()}
            </span>
            <span className="text-stone-500 dark:text-stone-400 text-xs font-medium block mt-1">
              Active pig heads
            </span>
          </div>
          <span className="text-[10px] text-stone-400 dark:text-stone-500 font-mono">SWINE BIOSECURITY PROTOCOLS IN FORCE</span>
        </div>

        {/* CARD 5: TOTAL POULTRY LIVESTOCK */}
        <div className="bg-white dark:bg-stone-900 p-6 rounded-[2rem] border border-stone-200/50 dark:border-stone-800 shadow-sm flex flex-col justify-between min-h-[180px] hover:border-emerald-200 dark:hover:border-stone-800 hover:shadow-md transition-all duration-300">
          <div className="flex justify-between items-start">
            <span className="text-stone-400 dark:text-stone-500 text-[10px] font-bold uppercase tracking-wider block">Poultry Livestock</span>
            <div className="h-8 w-8 bg-amber-50 dark:bg-stone-800 text-sm flex items-center justify-center rounded-xl select-none">
              🐔
            </div>
          </div>
          <div>
            <span className="text-4xl font-extrabold text-stone-900 dark:text-stone-100 tracking-tight block">
              {totalPoultry.toLocaleString()}
            </span>
            <span className="text-stone-500 dark:text-stone-400 text-xs font-medium block mt-1">
              Active poultry heads
            </span>
          </div>
          <span className="text-[10px] text-stone-400 dark:text-stone-500 font-mono">POULTRY ISOLATION BARRIERS IN FORCE</span>
        </div>

        {/* CARD 6: COMPLIANCE TREND CHART (Spans 3 cols on xl, 2 cols on lg/md) */}
        <div className="bg-white dark:bg-stone-900 p-6 sm:p-8 rounded-[2rem] border border-stone-200/50 dark:border-stone-800 shadow-sm md:col-span-2 lg:col-span-2 xl:col-span-3 hover:shadow-md transition duration-300">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
            <div>
              <h3 className="text-base font-extrabold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-emerald-600" />
                Compliance Trend Metrics
              </h3>
              <p className="text-stone-500 dark:text-stone-400 text-xs">Aesthetic timeline tracking daily sanitary safety checks</p>
            </div>
            <button 
              onClick={() => onNavigate('biosecurity')}
              className="px-3.5 py-1.5 bg-[#f4f7f5] dark:bg-stone-850 hover:bg-emerald-50 dark:hover:bg-emerald-950/20 text-emerald-800 dark:text-emerald-400 text-[11px] font-bold rounded-xl flex items-center gap-1 cursor-pointer transition border border-stone-100 dark:border-stone-800"
            >
              Audits Hub
              <ArrowRight className="h-3 w-3" />
            </button>
          </div>
          
          <div className="h-64 sm:h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={complianceData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorCompliance" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.25}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e5e0" className="dark:stroke-stone-800" />
                <XAxis dataKey="date" stroke="#a8a29e" fontSize={10} tickLine={false} />
                <YAxis domain={[0, 100]} stroke="#a8a29e" fontSize={10} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#ffffff', borderRadius: '16px', border: '1px solid #e7e5e4', fontSize: '11px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)', color: '#000000' }}
                  formatter={(value) => [`${value}% Compliance`, 'Sanitation Score']}
                />
                <Area type="monotone" dataKey="compliance" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorCompliance)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* CARD 7: LIVESTOCK BREAKDOWN PIE CHART (Col-span 1) */}
        <div className="bg-white dark:bg-stone-900 p-6 rounded-[2rem] border border-stone-200/50 dark:border-stone-800 shadow-sm flex flex-col justify-between min-h-[300px] hover:shadow-md transition duration-300">
          <div>
            <h3 className="text-sm font-extrabold text-stone-900 dark:text-stone-100 flex items-center gap-2">
              <Activity className="h-4.5 w-4.5 text-emerald-600" />
              Livestock Mix
            </h3>
            <p className="text-stone-500 dark:text-stone-400 text-xs">Proportional swine/poultry share</p>
          </div>
          
          <div className="h-40 relative flex items-center justify-center my-2">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={distributionData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={68}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {distributionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => [value, 'Heads']} />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute text-center flex flex-col items-center justify-center">
              <span className="text-xl font-black text-stone-900 dark:text-stone-50 leading-none">
                {(totalPigs + totalPoultry || 1590).toLocaleString()}
              </span>
              <span className="text-[9px] text-stone-400 dark:text-stone-500 uppercase tracking-widest font-bold mt-1 block">Total</span>
            </div>
          </div>

          <div className="space-y-1.5 mt-2">
            {distributionData.map((data, idx) => {
              const total = totalPigs + totalPoultry;
              const pct = total > 0 ? Math.round((data.value / total) * 100) : idx === 0 ? 21 : 79;
              return (
                <div key={idx} className="flex justify-between items-center border-t border-stone-100 dark:border-stone-800 pt-2 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: data.color }}></span>
                    <span className="font-bold text-stone-700 dark:text-stone-300">{data.name}</span>
                  </div>
                  <span className="font-mono text-stone-950 dark:text-stone-100 text-[11px] font-bold">{data.value.toLocaleString()} heads ({pct}%)</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* CARD 8: ACTIVE HEALTH ALERTS (Col-span 2 on lg/xl) */}
        <div className="bg-white dark:bg-stone-900 p-6 rounded-[2rem] border border-stone-200/50 dark:border-stone-800 shadow-sm md:col-span-1 lg:col-span-1 xl:col-span-2 hover:shadow-md transition duration-300 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="text-sm font-extrabold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                  <ShieldAlert className="h-4.5 w-4.5 text-rose-500" />
                  Symptom Warnings
                </h3>
                <p className="text-stone-500 dark:text-stone-400 text-xs">Most recent veterinary logs & sickness status</p>
              </div>
              <button 
                onClick={() => onNavigate('health')}
                className="text-rose-700 dark:text-rose-400 text-xs font-bold hover:underline cursor-pointer"
              >
                Health Logs
              </button>
            </div>

            {activeDiseaseAlerts.length === 0 ? (
              <div className="text-center py-10 bg-[#fbfcfb] dark:bg-stone-850/55 rounded-2xl border border-dashed border-stone-200/60 dark:border-stone-800 my-2">
                <span className="text-3xl block mb-2">🌿</span>
                <p className="text-stone-700 dark:text-stone-300 text-xs font-bold">Safe Zone: Zero active sicknesses</p>
                <p className="text-stone-400 dark:text-stone-500 text-[10px] mt-0.5">Biosecurity and farm protocols are working perfectly.</p>
              </div>
            ) : (
              <div className="space-y-3.5 my-2">
                {activeDiseaseAlerts.map((alert) => {
                  const farmObj = farms.find(f => f.id === alert.farmId);
                  return (
                    <div key={alert.id} className="p-3.5 bg-stone-50 dark:bg-stone-850/40 border border-stone-150 dark:border-stone-800/80 rounded-2xl flex justify-between items-start">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded-lg text-[9px] font-extrabold uppercase bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-400 border border-rose-100/30">
                            {alert.disease}
                          </span>
                          <span className="text-[10px] text-stone-500 dark:text-stone-400 font-bold">
                            {farmObj ? farmObj.name : 'Unknown Farm'}
                          </span>
                        </div>
                        <p className="text-[11px] text-stone-600 dark:text-stone-300">
                          <strong className="text-stone-900 dark:text-stone-200">Symptoms:</strong> {alert.symptoms}
                        </p>
                        <p className="text-[11px] text-emerald-800 dark:text-emerald-400 font-medium">
                          <strong className="text-emerald-950 dark:text-emerald-300">Treatment:</strong> {alert.treatment}
                        </p>
                      </div>
                      <span className="text-[9px] font-mono text-stone-400 shrink-0">
                        {new Date(alert.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
          <div className="text-[10px] text-stone-400 font-mono mt-2">ALERTS SYNCHRONIZED REALTIME FROM FIRESTORE</div>
        </div>

        {/* CARD 9: VACCINATION DEADLINES (Col-span 2 on lg/xl) */}
        <div className="bg-white dark:bg-stone-900 p-6 rounded-[2rem] border border-stone-200/50 dark:border-stone-800 shadow-sm md:col-span-1 lg:col-span-1 xl:col-span-2 hover:shadow-md transition duration-300 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="text-sm font-extrabold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                  <Syringe className="h-4.5 w-4.5 text-emerald-600" />
                  Upcoming Immunizations
                </h3>
                <p className="text-stone-500 dark:text-stone-400 text-xs">Upcoming doses & critical health safeguards</p>
              </div>
              <button 
                onClick={() => onNavigate('vaccinations')}
                className="text-emerald-700 dark:text-emerald-400 text-xs font-bold hover:underline cursor-pointer"
              >
                Vaccine Hub
              </button>
            </div>

            {pendingVaccines.length === 0 ? (
              <div className="text-center py-10 bg-[#fbfcfb] dark:bg-stone-850/55 rounded-2xl border border-dashed border-stone-200/60 dark:border-stone-800 my-2">
                <span className="text-3xl block mb-2">🛡️</span>
                <p className="text-stone-700 dark:text-stone-300 text-xs font-bold">All vaccination programs complete</p>
                <p className="text-stone-400 dark:text-stone-500 text-[10px] mt-0.5">Maintain periodic logs as required.</p>
              </div>
            ) : (
              <div className="space-y-3.5 my-2">
                {pendingVaccines.slice(0, 3).map((vacc) => {
                  const farmObj = farms.find(f => f.id === vacc.farmId);
                  const isOverdue = vacc.status === 'overdue';
                  return (
                    <div key={vacc.id} className="p-3.5 bg-stone-50 dark:bg-stone-850/40 border border-stone-150 dark:border-stone-800/80 rounded-2xl flex justify-between items-center">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-stone-900 dark:text-stone-100 text-xs">{vacc.vaccineName}</span>
                          <span className={`px-2 py-0.5 rounded-md text-[8px] font-extrabold uppercase tracking-wide border ${
                            isOverdue 
                              ? 'bg-rose-50 text-rose-800 border-rose-100 dark:bg-rose-950/40 dark:text-rose-400' 
                              : 'bg-emerald-50 text-emerald-800 border-emerald-100 dark:bg-emerald-950/40 dark:text-emerald-400'
                          }`}>
                            {vacc.status}
                          </span>
                        </div>
                        <p className="text-[10px] text-stone-400 dark:text-stone-500 font-bold">
                          {farmObj ? `${farmObj.name} (${farmObj.farmType})` : 'Farm Facility'}
                        </p>
                      </div>
                      <div className="text-right">
                        <span className="text-[8px] text-stone-400 dark:text-stone-500 block uppercase font-bold tracking-wider">Due Date</span>
                        <span className={`text-[11px] font-bold font-mono ${isOverdue ? 'text-rose-600' : 'text-stone-700 dark:text-stone-300'}`}>
                          {new Date(vacc.nextDueDate).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
          <div className="text-[10px] text-stone-400 font-mono mt-2">VACCINES SCHEDULE GENERATOR LIVE ACTIVE</div>
        </div>

        {/* CARD 10: QUICK ACTIONS TOOLBAR (Full Width on Grid) */}
        <div className="bg-stone-100/50 dark:bg-stone-850/40 p-6 rounded-[2rem] border border-stone-200/40 dark:border-stone-800/60 md:col-span-2 lg:col-span-3 xl:col-span-4 hover:shadow-sm transition mt-2">
          <h4 className="text-[10px] font-extrabold text-stone-500 dark:text-stone-400 mb-3.5 uppercase tracking-widest font-mono">Quick Access Terminal</h4>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <button 
              onClick={() => onNavigate('farms')}
              className="flex items-center gap-2.5 p-4 bg-white dark:bg-stone-900 border border-stone-200/50 dark:border-stone-850 hover:border-emerald-300 dark:hover:border-stone-700 rounded-2xl font-bold text-xs text-stone-700 dark:text-stone-200 hover:text-emerald-800 dark:hover:text-emerald-400 hover:shadow-sm transition cursor-pointer group"
            >
              <PlusCircle className="h-4.5 w-4.5 text-emerald-600 group-hover:scale-110 transition" />
              Add New Farm
            </button>
            <button 
              onClick={() => onNavigate('biosecurity')}
              className="flex items-center gap-2.5 p-4 bg-white dark:bg-stone-900 border border-stone-200/50 dark:border-stone-850 hover:border-emerald-300 dark:hover:border-stone-700 rounded-2xl font-bold text-xs text-stone-700 dark:text-stone-200 hover:text-emerald-800 dark:hover:text-emerald-400 hover:shadow-sm transition cursor-pointer group"
            >
              <ClipboardList className="h-4.5 w-4.5 text-emerald-600 group-hover:scale-110 transition" />
              Perform Daily Check
            </button>
            <button 
              onClick={() => onNavigate('health')}
              className="flex items-center gap-2.5 p-4 bg-white dark:bg-stone-900 border border-stone-200/50 dark:border-stone-850 hover:border-emerald-300 dark:hover:border-stone-700 rounded-2xl font-bold text-xs text-stone-700 dark:text-stone-200 hover:text-emerald-800 dark:hover:text-emerald-400 hover:shadow-sm transition cursor-pointer group"
            >
              <ShieldAlert className="h-4.5 w-4.5 text-emerald-600 group-hover:scale-110 transition" />
              Report Sickness
            </button>
            <button 
              onClick={() => onNavigate('reports')}
              className="flex items-center gap-2.5 p-4 bg-white dark:bg-stone-900 border border-stone-200/50 dark:border-stone-850 hover:border-emerald-300 dark:hover:border-stone-700 rounded-2xl font-bold text-xs text-stone-700 dark:text-stone-200 hover:text-emerald-800 dark:hover:text-emerald-400 hover:shadow-sm transition cursor-pointer group"
            >
              <TrendingUp className="h-4.5 w-4.5 text-emerald-600 group-hover:scale-110 transition" />
              Export Farm PDF
            </button>
          </div>
        </div>

      </div>

    </motion.div>
  );
}
