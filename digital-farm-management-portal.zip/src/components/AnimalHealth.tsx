import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ShieldAlert, Activity, Heart, Syringe, Plus, FileText, Calendar, Camera } from 'lucide-react';
import { Farm, HealthRecord, Role } from '../types';

interface HealthProps {
  farms: Farm[];
  healthRecords: HealthRecord[];
  role: Role;
  onAddHealthRecord: (record: Omit<HealthRecord, 'id' | 'recordedBy' | 'createdAt'>) => Promise<void>;
}

// Predefined illustrative presets for livestock medical reference
const PHOTO_PRESETS = [
  { label: 'Healthy Livestock', url: 'https://images.unsplash.com/photo-1516467508483-a7212febe31a?w=150&auto=format&fit=crop&q=60&ixlib=rb-4.0.3', emoji: '🐷' },
  { label: 'Skin Lesions Reference', url: 'https://images.unsplash.com/photo-1605001011156-cbf0b0f67a51?w=150&auto=format&fit=crop&q=60&ixlib=rb-4.0.3', emoji: '🔍' },
  { label: 'Fowl Lethargy / Respiratory', url: 'https://images.unsplash.com/photo-1548767797-d8c844163c4c?w=150&auto=format&fit=crop&q=60&ixlib=rb-4.0.3', emoji: '🐔' },
  { label: 'Veterinary Examination', url: 'https://images.unsplash.com/photo-1584132967334-10e028bd69f7?w=150&auto=format&fit=crop&q=60&ixlib=rb-4.0.3', emoji: '🩺' }
];

export default function AnimalHealth({ farms, healthRecords, role, onAddHealthRecord }: HealthProps) {
  
  const [selectedFarmId, setSelectedFarmId] = useState<string>(farms[0]?.id || '');
  const [disease, setDisease] = useState('');
  const [symptoms, setSymptoms] = useState('');
  const [treatment, setTreatment] = useState('');
  const [medicineDetails, setMedicineDetails] = useState('');
  const [veterinaryVisitHistory, setVeterinaryVisitHistory] = useState('');
  const [photoUrl, setPhotoUrl] = useState(PHOTO_PRESETS[0].url);

  const [loading, setLoading] = useState(false);
  const [showAddForm, setShowAddForm] = useState(false);

  // Filter for currently selected farm
  const activeRecords = healthRecords.filter(r => r.farmId === selectedFarmId);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFarmId) {
      alert('Please select a farm unit first.');
      return;
    }
    if (!disease.trim() || !symptoms.trim() || !treatment.trim()) {
      alert('Disease, symptoms, and treatment details are required.');
      return;
    }

    setLoading(true);
    try {
      await onAddHealthRecord({
        farmId: selectedFarmId,
        disease: disease.trim(),
        symptoms: symptoms.trim(),
        treatment: treatment.trim(),
        medicineDetails: medicineDetails.trim(),
        veterinaryVisitHistory: veterinaryVisitHistory.trim(),
        photoUrl
      });

      // Reset
      setDisease('');
      setSymptoms('');
      setTreatment('');
      setMedicineDetails('');
      setVeterinaryVisitHistory('');
      setShowAddForm(false);
    } catch (err: any) {
      alert(err.message || 'Failed to record health event.');
    } finally {
      setLoading(false);
    }
  };

  const selectedFarmObj = farms.find(f => f.id === selectedFarmId);

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-6"
    >
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm flex flex-col sm:flex-row justify-between items-center gap-4">
        <div className="flex items-center gap-3">
          <Heart className="h-6 w-6 text-rose-500 shrink-0" />
          <div>
            <h3 className="font-extrabold text-stone-900 text-sm sm:text-base">Animal Health Management</h3>
            <p className="text-stone-500 text-xs">Record symptoms, diagnose diseases, prescribe medication, and trace vet visits</p>
          </div>
        </div>
        <div className="w-full sm:w-auto flex items-center gap-2">
          <select
            value={selectedFarmId}
            onChange={(e) => setSelectedFarmId(e.target.value)}
            className="w-full sm:w-64 px-3 py-2 border border-stone-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold bg-stone-50"
          >
            {farms.length === 0 ? (
              <option value="">No registered farms found</option>
            ) : (
              farms.map(f => (
                <option key={f.id} value={f.id}>
                  {f.name} ({f.farmType})
                </option>
              ))
            )}
          </select>
          {farms.length > 0 && !showAddForm && (
            <button
              onClick={() => setShowAddForm(true)}
              className="bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl flex items-center gap-1 shrink-0 transition shadow-sm cursor-pointer"
            >
              <Plus className="h-4 w-4" />
              Log Sickness
            </button>
          )}
        </div>
      </div>

      {farms.length === 0 ? (
        <div className="text-center py-16 bg-white border border-stone-200 rounded-2xl">
          <ShieldAlert className="h-12 w-12 text-stone-300 mx-auto mb-3" />
          <p className="font-bold text-stone-700">Please Register a Farm Unit First</p>
          <p className="text-stone-500 text-xs mt-1">You must configure a farm unit to record livestock health observations.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* LEFT/COL 1: LOG SICKNESS FORM */}
          {showAddForm && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="lg:col-span-1 bg-white p-6 rounded-2xl border border-rose-100 shadow-md h-fit space-y-4"
            >
              <div className="flex justify-between items-center pb-2 border-b border-stone-100">
                <h4 className="font-bold text-rose-900 text-sm flex items-center gap-1.5">
                  <ShieldAlert className="h-4.5 w-4.5 text-rose-600" />
                  Log Medical Record
                </h4>
                <button 
                  onClick={() => setShowAddForm(false)}
                  className="text-stone-400 hover:text-stone-600 text-xs font-bold"
                >
                  Close
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-700 block">Diagnosed Disease / Condition</label>
                  <input
                    type="text"
                    value={disease}
                    onChange={(e) => setDisease(e.target.value)}
                    placeholder="e.g. Swine Vesicular Disease / Coccidiosis"
                    className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs focus:ring-rose-500 focus:outline-none focus:ring-2"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-700 block">Observed Symptoms</label>
                  <textarea
                    value={symptoms}
                    onChange={(e) => setSymptoms(e.target.value)}
                    placeholder="e.g. Blisters on snout, high fever, decreased appetite"
                    className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs focus:ring-rose-500 focus:outline-none focus:ring-2 h-16 resize-none"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-700 block">Prescribed Treatment / Protocol</label>
                  <input
                    type="text"
                    value={treatment}
                    onChange={(e) => setTreatment(e.target.value)}
                    placeholder="e.g. Isolation, electrolyte therapy, strict gating"
                    className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs focus:ring-rose-500 focus:outline-none focus:ring-2"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-700 block">Medicine & Dosage Details</label>
                  <input
                    type="text"
                    value={medicineDetails}
                    onChange={(e) => setMedicineDetails(e.target.value)}
                    placeholder="e.g. Amoxicillin 15mg, added to water for 5 days"
                    className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs focus:ring-rose-500 focus:outline-none focus:ring-2"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-700 block">Veterinary Visit History / Dr Notes</label>
                  <input
                    type="text"
                    value={veterinaryVisitHistory}
                    onChange={(e) => setVeterinaryVisitHistory(e.target.value)}
                    placeholder="e.g. Examined by Dr. Henderson, follow-up scheduled"
                    className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs focus:ring-rose-500 focus:outline-none focus:ring-2"
                  />
                </div>

                {/* Photo reference preset selector */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-700 flex items-center gap-1">
                    <Camera className="h-3.5 w-3.5 text-stone-400" /> Medical Image Reference
                  </label>
                  <div className="grid grid-cols-4 gap-1.5 mt-1">
                    {PHOTO_PRESETS.map((preset, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setPhotoUrl(preset.url)}
                        className={`p-1.5 rounded-lg border text-center text-xs flex flex-col items-center justify-center relative cursor-pointer ${
                          photoUrl === preset.url 
                            ? 'border-rose-500 bg-rose-50/55' 
                            : 'border-stone-100 bg-stone-50 hover:bg-stone-100'
                        }`}
                        title={preset.label}
                      >
                        <span className="text-base">{preset.emoji}</span>
                        <span className="text-[8px] font-mono tracking-tighter mt-1 text-stone-600 block truncate max-w-full">{preset.label.split(' ')[0]}</span>
                        {photoUrl === preset.url && (
                          <span className="absolute -top-1 -right-1 bg-rose-600 text-white text-[8px] h-3 w-3 rounded-full flex items-center justify-center font-bold">✓</span>
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-sm transition uppercase cursor-pointer"
                >
                  {loading ? 'Recording...' : 'File Health Report'}
                </button>
              </form>
            </motion.div>
          )}

          {/* HEALTH RECORDS LOGS */}
          <div className={`${showAddForm ? 'lg:col-span-2' : 'lg:col-span-3'} bg-white p-6 rounded-2xl border border-stone-200 shadow-sm`}>
            <h4 className="font-extrabold text-stone-900 text-base mb-4 flex items-center gap-2">
              <Activity className="h-5 w-5 text-rose-500" />
              Health Observation logs
            </h4>

            {activeRecords.length === 0 ? (
              <div className="text-center py-16 bg-stone-50 rounded-2xl border border-dashed border-stone-200">
                <span className="text-2xl block mb-1">🛡️</span>
                <p className="font-bold text-stone-700 text-sm">Perfect Health Ledger</p>
                <p className="text-stone-500 text-xs mt-0.5">No livestock disease or sickness records found in the selected facility.</p>
              </div>
            ) : (
              <div className="space-y-6 max-h-[550px] overflow-y-auto pr-2">
                {activeRecords.slice().reverse().map((record) => (
                  <div 
                    key={record.id}
                    className="p-5 border border-stone-250 bg-stone-50/50 rounded-2xl flex flex-col md:flex-row gap-5 items-start justify-between"
                  >
                    <div className="space-y-3 flex-grow">
                      {/* Header tags */}
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="bg-rose-50 text-rose-800 border border-rose-100 px-3 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wide">
                          DISEASE: {record.disease}
                        </span>
                        <span className="text-stone-400 font-mono text-[10px]">
                          Reported: {new Date(record.createdAt).toLocaleDateString()}
                        </span>
                      </div>

                      {/* Diagnostic details */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-stone-100">
                        <div className="space-y-0.5">
                          <span className="text-[10px] uppercase font-bold tracking-wider text-stone-400 block">SYMPTOMS RECORDED</span>
                          <p className="text-xs text-stone-700 font-semibold">{record.symptoms}</p>
                        </div>
                        <div className="space-y-0.5">
                          <span className="text-[10px] uppercase font-bold tracking-wider text-stone-400 block">PRESCRIBED TREATMENT</span>
                          <p className="text-xs text-emerald-800 font-semibold">{record.treatment}</p>
                        </div>
                      </div>

                      {/* Medicine and Veterinary logs */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-stone-100">
                        {record.medicineDetails && (
                          <div className="space-y-0.5">
                            <span className="text-[10px] uppercase font-bold tracking-wider text-stone-400 block">MEDICATION DOSAGE</span>
                            <p className="text-xs text-stone-600 italic font-medium">💊 {record.medicineDetails}</p>
                          </div>
                        )}
                        {record.veterinaryVisitHistory && (
                          <div className="space-y-0.5">
                            <span className="text-[10px] uppercase font-bold tracking-wider text-stone-400 block">VETERINARY VISITS & NOTES</span>
                            <p className="text-xs text-stone-600 font-medium">🩺 {record.veterinaryVisitHistory}</p>
                          </div>
                        )}
                      </div>

                      <div className="pt-2 text-[9px] text-stone-400 font-mono">
                        Logged by: {record.recordedBy}
                      </div>
                    </div>

                    {/* Photo preview (referring to the image generation rules referrerPolicy="no-referrer") */}
                    {record.photoUrl && (
                      <div className="w-24 h-24 rounded-xl overflow-hidden border border-stone-200 shrink-0 relative shadow-sm group">
                        <img 
                          src={record.photoUrl} 
                          alt="Disease Reference"
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover group-hover:scale-105 transition"
                        />
                        <span className="absolute bottom-0 left-0 right-0 bg-stone-900/60 text-white text-[8px] font-semibold text-center py-0.5">IMAGE</span>
                      </div>
                    )}

                  </div>
                ))}
              </div>
            )}
          </div>

        </div>
      )}

    </motion.div>
  );
}
