import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  ClipboardCheck, Footprints, ShieldCheck, ShieldAlert, Sparkles, 
  Trash2, UserCheck, Eye, Clipboard, Users, Calendar, Clock, Plus, CheckCircle2 
} from 'lucide-react';
import { Farm, BiosecurityChecklist, VisitorLog, Role } from '../types';

interface BiosecurityProps {
  farms: Farm[];
  checklists: BiosecurityChecklist[];
  visitorLogs: VisitorLog[];
  role: Role;
  onAddChecklist: (checklist: Omit<BiosecurityChecklist, 'id' | 'completedBy' | 'createdAt'>) => Promise<void>;
  onAddVisitorLog: (log: Omit<VisitorLog, 'id' | 'loggedBy'>) => Promise<void>;
  onToggleVisitorClearance: (farmId: string, logId: string, cleared: boolean) => Promise<void>;
}

export default function Biosecurity({ 
  farms, 
  checklists, 
  visitorLogs, 
  role,
  onAddChecklist, 
  onAddVisitorLog,
  onToggleVisitorClearance
}: BiosecurityProps) {

  // Active Farm for current view
  const [selectedFarmId, setSelectedFarmId] = useState<string>(farms[0]?.id || '');

  // Daily checklist form states
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [visitorEntryLog, setVisitorEntryLog] = useState(false);
  const [footbathMaintenance, setFootbathMaintenance] = useState(false);
  const [handSanitization, setHandSanitization] = useState(false);
  const [protectiveClothing, setProtectiveClothing] = useState(false);
  const [vehicleDisinfection, setVehicleDisinfection] = useState(false);
  const [equipmentCleaning, setEquipmentCleaning] = useState(false);
  const [feedInspection, setFeedInspection] = useState(false);
  const [waterInspection, setWaterInspection] = useState(false);
  const [wasteMonitoring, setWasteMonitoring] = useState(false);
  const [deadAnimalDisposal, setDeadAnimalDisposal] = useState(false);

  // Visitor Log form states
  const [visitorName, setVisitorName] = useState('');
  const [purpose, setPurpose] = useState('');
  const [cleared, setCleared] = useState(true);

  const [loading, setLoading] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Filter checklists and visitor logs for selected farm
  const activeChecklists = checklists.filter(c => c.farmId === selectedFarmId);
  const activeVisitorLogs = visitorLogs.filter(v => v.farmId === selectedFarmId);

  // Calculate realtime percentage
  const calculateCompliance = () => {
    const checks = [
      visitorEntryLog, footbathMaintenance, handSanitization, protectiveClothing,
      vehicleDisinfection, equipmentCleaning, feedInspection, waterInspection,
      wasteMonitoring, deadAnimalDisposal
    ];
    const totalChecked = checks.filter(Boolean).length;
    return totalChecked * 10;
  };

  const percentage = calculateCompliance();
  
  const getStatusIndicator = (pct: number) => {
    if (pct >= 90) return { label: 'Compliant', color: 'text-emerald-600 bg-emerald-50 border-emerald-200', dot: 'bg-emerald-500' };
    if (pct >= 70) return { label: 'Caution', color: 'text-amber-600 bg-amber-50 border-amber-200', dot: 'bg-amber-500' };
    return { label: 'Non-Compliant', color: 'text-rose-600 bg-rose-50 border-rose-200', dot: 'bg-rose-500' };
  };

  const status = getStatusIndicator(percentage);

  // Submit Daily Checklist
  const handleSubmitChecklist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFarmId) {
      alert('Please register or select a farm first.');
      return;
    }
    setLoading(true);
    try {
      const compliancePct = calculateCompliance();
      const statusStr = compliancePct >= 90 ? 'green' : compliancePct >= 70 ? 'yellow' : 'red';
      
      await onAddChecklist({
        farmId: selectedFarmId,
        date,
        visitorEntryLog,
        footbathMaintenance,
        handSanitization,
        protectiveClothing,
        vehicleDisinfection,
        equipmentCleaning,
        feedInspection,
        waterInspection,
        wasteMonitoring,
        deadAnimalDisposal,
        compliancePercentage: compliancePct,
        status: statusStr
      });

      setToastMsg('Daily biosecurity checklist submitted successfully!');
      setTimeout(() => setToastMsg(null), 3000);
      
      // Reset checklist toggles
      setVisitorEntryLog(false);
      setFootbathMaintenance(false);
      setHandSanitization(false);
      setProtectiveClothing(false);
      setVehicleDisinfection(false);
      setEquipmentCleaning(false);
      setFeedInspection(false);
      setWaterInspection(false);
      setWasteMonitoring(false);
      setDeadAnimalDisposal(false);
    } catch (err: any) {
      alert(err.message || 'Failed to submit checklist');
    } finally {
      setLoading(false);
    }
  };

  // Submit Visitor Log
  const handleSubmitVisitor = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFarmId) {
      alert('Please select a farm first.');
      return;
    }
    if (!visitorName.trim() || !purpose.trim()) {
      alert('Visitor name and purpose are required.');
      return;
    }
    setLoading(true);
    try {
      await onAddVisitorLog({
        farmId: selectedFarmId,
        visitorName: visitorName.trim(),
        purpose: purpose.trim(),
        entryTime: new Date().toISOString(),
        cleared
      });

      setVisitorName('');
      setPurpose('');
      setCleared(true);
      
      setToastMsg('Visitor logged successfully.');
      setTimeout(() => setToastMsg(null), 3000);
    } catch (err: any) {
      alert(err.message || 'Failed to log visitor.');
    } finally {
      setLoading(false);
    }
  };

  const currentFarm = farms.find(f => f.id === selectedFarmId);

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-8"
    >
      {/* Top Selector bar */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm flex flex-col sm:flex-row justify-between items-center gap-4">
        <div className="flex items-center gap-3">
          <ClipboardCheck className="h-6 w-6 text-emerald-600 shrink-0" />
          <div>
            <h3 className="font-extrabold text-stone-900 text-sm sm:text-base">Biosecurity & Sanitation Logs</h3>
            <p className="text-stone-500 text-xs">Verify sanitization protocols and log farm visits</p>
          </div>
        </div>
        <div className="w-full sm:w-auto">
          <select
            value={selectedFarmId}
            onChange={(e) => setSelectedFarmId(e.target.value)}
            className="w-full sm:w-64 px-3 py-2 border border-stone-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold bg-stone-50"
          >
            {farms.length === 0 ? (
              <option value="">No registered farms found</option>
            ) : (
              farms.map(f => (
                <option key={f.id} value={f.id}>
                  {f.name} ({f.farmType})
                </option>
              ))
            )}
          </select>
        </div>
      </div>

      {toastMsg && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs px-4 py-3 rounded-xl flex items-center gap-2 font-semibold shadow-sm">
          <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
          <span>{toastMsg}</span>
        </div>
      )}

      {farms.length === 0 ? (
        <div className="text-center py-16 bg-white border border-stone-200 rounded-2xl">
          <ShieldAlert className="h-12 w-12 text-stone-300 mx-auto mb-3" />
          <p className="font-bold text-stone-700">Please Register a Farm Unit First</p>
          <p className="text-stone-500 text-xs mt-1">You must configure a farm to begin daily checklists and visitor registers.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* DAILY BIOPROCESS CHECKLIST */}
          <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-stone-200 shadow-sm flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-start gap-4 mb-4 pb-3 border-b border-stone-100">
                <div>
                  <h4 className="font-extrabold text-stone-900 text-base">Daily Compliance Check</h4>
                  <p className="text-stone-500 text-xs mt-0.5">Fulfill all required protocols and track compliance rate</p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-stone-400 block font-mono">SELECTED UNIT</span>
                  <span className="font-bold text-xs text-emerald-800">{currentFarm?.name}</span>
                </div>
              </div>

              <form onSubmit={handleSubmitChecklist} className="space-y-6">
                
                {/* Date Input */}
                <div className="flex items-center gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-stone-600 flex items-center gap-1">
                      <Calendar className="h-3.5 w-3.5" /> Checklist Date
                    </label>
                    <input
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="px-3 py-1.5 border border-stone-200 rounded-lg text-xs font-mono font-bold"
                      required
                    />
                  </div>
                </div>

                {/* 10 Biosecurity Rules with Custom Styles */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  {[
                    { id: 'visitor', label: 'Visitor Entry Log Checked', checked: visitorEntryLog, setter: setVisitorEntryLog, desc: 'Verify visitor log is completed prior to entry' },
                    { id: 'footbath', label: 'Footbath Maintenance Done', checked: footbathMaintenance, setter: setFootbathMaintenance, desc: 'Re-filled footbath disinfectant fluid' },
                    { id: 'hand', label: 'Hand Sanitization Enforced', checked: handSanitization, setter: setHandSanitization, desc: 'Workers sanitized hands upon boarding' },
                    { id: 'clothing', label: 'Protective Outer Gear Worn', checked: protectiveClothing, setter: setProtectiveClothing, desc: 'Strict boot covers and clean overalls usage' },
                    { id: 'vehicle', label: 'Vehicle Disinfection Sprayed', checked: vehicleDisinfection, setter: setVehicleDisinfection, desc: 'Wheels & chassis sanitized at farm gate' },
                    { id: 'equipment', label: 'Equipment Cleaning Performed', checked: equipmentCleaning, setter: setEquipmentCleaning, desc: 'Feed & water containers sterilised' },
                    { id: 'feed', label: 'Feed Quality Inspected', checked: feedInspection, setter: setFeedInspection, desc: 'Ensured feeds are dry, safe, mold-free' },
                    { id: 'water', label: 'Water Quality Monitored', checked: waterInspection, setter: setWaterInspection, desc: 'Water sanitiser and filters verified' },
                    { id: 'waste', label: 'Waste Disposal Monitored', checked: wasteMonitoring, setter: setWasteMonitoring, desc: 'Excreta and waste bins cleared' },
                    { id: 'dead', label: 'Dead Animal Disposal Audited', checked: deadAnimalDisposal, setter: setDeadAnimalDisposal, desc: 'Proper containment or composting log' }
                  ].map((rule) => (
                    <label 
                      key={rule.id}
                      className={`p-3.5 border rounded-xl flex items-start gap-3 cursor-pointer select-none transition ${
                        rule.checked 
                          ? 'bg-emerald-50/50 border-emerald-200 shadow-sm' 
                          : 'border-stone-100 hover:bg-stone-50'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={rule.checked}
                        onChange={(e) => rule.setter(e.target.checked)}
                        className="h-4.5 w-4.5 text-emerald-600 border-stone-300 rounded focus:ring-emerald-500 mt-0.5 cursor-pointer"
                      />
                      <div className="space-y-0.5">
                        <span className={`text-xs font-bold ${rule.checked ? 'text-emerald-950' : 'text-stone-800'}`}>
                          {rule.label}
                        </span>
                        <p className="text-[10px] text-stone-500 leading-normal">{rule.desc}</p>
                      </div>
                    </label>
                  ))}
                </div>

                {/* Score & Submit Action */}
                <div className="bg-stone-50 p-5 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4 border border-stone-200 mt-6">
                  <div className="flex items-center gap-4 w-full sm:w-auto">
                    {/* Ring score */}
                    <div className="h-16 w-16 rounded-full border-4 border-stone-200 flex items-center justify-center relative overflow-hidden bg-white shrink-0">
                      <div className="text-center">
                        <span className="text-sm font-black text-stone-900 block leading-none">{percentage}%</span>
                        <span className="text-[8px] text-stone-400 font-mono tracking-tighter uppercase mt-0.5 block">SCORE</span>
                      </div>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-mono tracking-wider text-stone-400 block">Compliance Grade</span>
                      <div className="flex items-center gap-1.5">
                        <span className={`h-2 w-2 rounded-full ${status.dot}`}></span>
                        <span className="text-xs font-bold text-stone-800">{status.label}</span>
                      </div>
                      <p className="text-[10px] text-stone-500 mt-0.5 max-w-xs">90% or higher is mandatory for standard safety clearance.</p>
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full sm:w-auto px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md cursor-pointer transition uppercase tracking-wide"
                  >
                    {loading ? 'Submitting...' : 'Log Daily Checklist'}
                  </button>
                </div>

              </form>
            </div>
          </div>

          {/* VISITOR VISITS LOG PANEL */}
          <div className="space-y-6">
            
            {/* Add Visitor Log form */}
            <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
              <h4 className="font-extrabold text-stone-900 text-base mb-1 flex items-center gap-2">
                <Users className="h-5 w-5 text-emerald-600" />
                Visitor Entry Log
              </h4>
              <p className="text-stone-500 text-xs mb-4">Record guest check-ins for the selected farm unit</p>

              <form onSubmit={handleSubmitVisitor} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-700 block">Visitor Full Name</label>
                  <input
                    type="text"
                    value={visitorName}
                    onChange={(e) => setVisitorName(e.target.value)}
                    placeholder="e.g. Dr. Arthur Pendelton"
                    className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs focus:ring-emerald-500 focus:outline-none focus:ring-2"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-700 block">Purpose of Visit</label>
                  <input
                    type="text"
                    value={purpose}
                    onChange={(e) => setPurpose(e.target.value)}
                    placeholder="e.g. Veterinary Inspection / Feed Delivery"
                    className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs focus:ring-emerald-500 focus:outline-none focus:ring-2"
                    required
                  />
                </div>

                <label className="flex items-center gap-2.5 p-2 bg-stone-50 border border-stone-150 rounded-lg cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={cleared}
                    onChange={(e) => setCleared(e.target.checked)}
                    className="h-4.5 w-4.5 text-emerald-600 border-stone-300 rounded focus:ring-emerald-500"
                  />
                  <div className="text-left">
                    <span className="text-xs font-bold text-stone-800 block">Biosecurity Cleared?</span>
                    <span className="text-[10px] text-stone-500">Visitor sanitized, wearing protection</span>
                  </div>
                </label>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-sm transition flex justify-center items-center gap-1 cursor-pointer"
                >
                  <Plus className="h-4 w-4" />
                  Record Entry Log
                </button>
              </form>
            </div>

            {/* Visitor list */}
            <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
              <h4 className="font-extrabold text-stone-900 text-sm mb-3">Recent Visitors</h4>
              
              {activeVisitorLogs.length === 0 ? (
                <div className="text-center py-6 text-stone-400 text-xs">
                  No visitors logged recently.
                </div>
              ) : (
                <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
                  {activeVisitorLogs.slice().reverse().map((log) => (
                    <div key={log.id} className="p-3 border border-stone-100 rounded-xl flex justify-between items-start text-xs bg-stone-50">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-stone-900">{log.visitorName}</span>
                          <span className={`px-2 py-0.2 rounded-full text-[8px] font-extrabold uppercase border ${
                            log.cleared 
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-100' 
                              : 'bg-rose-50 text-rose-800 border-rose-100'
                          }`}>
                            {log.cleared ? 'Cleared' : 'Hazard'}
                          </span>
                        </div>
                        <p className="text-[10px] text-stone-600">{log.purpose}</p>
                        <div className="flex items-center gap-2 text-[9px] text-stone-400">
                          <Clock className="h-3 w-3" />
                          <span>{new Date(log.entryTime).toLocaleTimeString()}</span>
                        </div>
                      </div>
                      
                      {/* Action toggle clearance for presentation convenience */}
                      <button
                        onClick={() => onToggleVisitorClearance(log.farmId, log.id, !log.cleared)}
                        className="text-[9px] text-stone-400 hover:text-emerald-700 font-bold"
                        title="Toggle clearance"
                      >
                        Change Status
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>

        </div>
      )}

      {/* Historical logs table */}
      {farms.length > 0 && (
        <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
          <h4 className="font-extrabold text-stone-900 text-base mb-1">Checklist Audit Log</h4>
          <p className="text-stone-500 text-xs mb-4">Historical daily biosecurity submissions for verification and audit trails</p>

          {activeChecklists.length === 0 ? (
            <div className="text-center py-6 text-stone-400 text-xs">
              No audit logs available for selected farm.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-stone-50 text-stone-500 font-bold uppercase tracking-wider text-[10px] border-b border-stone-100">
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Score</th>
                    <th className="py-3 px-4">Compliance Status</th>
                    <th className="py-3 px-4">Checks Met</th>
                    <th className="py-3 px-4">Audited By</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-50">
                  {activeChecklists.slice().reverse().map((c) => {
                    const checksMet = [
                      c.visitorEntryLog, c.footbathMaintenance, c.handSanitization,
                      c.protectiveClothing, c.vehicleDisinfection, c.equipmentCleaning,
                      c.feedInspection, c.waterInspection, c.wasteMonitoring, c.deadAnimalDisposal
                    ].filter(Boolean).length;

                    return (
                      <tr key={c.id} className="hover:bg-stone-50/50">
                        <td className="py-3 px-4 font-mono text-stone-700 font-bold">{c.date}</td>
                        <td className="py-3 px-4 font-bold text-stone-900">{c.compliancePercentage}%</td>
                        <td className="py-3 px-4">
                          <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-extrabold uppercase ${
                            c.status === 'green' 
                              ? 'bg-emerald-50 text-emerald-800' 
                              : c.status === 'yellow' 
                                ? 'bg-amber-50 text-amber-800' 
                                : 'bg-rose-50 text-rose-800'
                          }`}>
                            {c.status === 'green' ? 'COMPLIANT' : c.status === 'yellow' ? 'WARNING' : 'HAZARD'}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-stone-600">{checksMet}/10 points met</td>
                        <td className="py-3 px-4 text-stone-500 font-medium">{c.completedBy}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

    </motion.div>
  );
}
