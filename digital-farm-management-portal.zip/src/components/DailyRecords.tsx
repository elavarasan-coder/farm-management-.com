import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, CartesianGrid 
} from 'recharts';
import { Clipboard, Plus, Calendar, Activity, BarChart2, ShieldAlert } from 'lucide-react';
import { Farm, DailyRecord, Role } from '../types';

interface DailyRecordsProps {
  farms: Farm[];
  dailyRecords: DailyRecord[];
  role: Role;
  onAddDailyRecord: (record: Omit<DailyRecord, 'id' | 'recordedBy' | 'createdAt'>) => Promise<void>;
}

export default function DailyRecords({ 
  farms, 
  dailyRecords, 
  role,
  onAddDailyRecord 
}: DailyRecordsProps) {

  const [selectedFarmId, setSelectedFarmId] = useState<string>(farms[0]?.id || '');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [feedConsumption, setFeedConsumption] = useState<number>(50);
  const [waterConsumption, setWaterConsumption] = useState<number>(200);
  const [mortalityCount, setMortalityCount] = useState<number>(0);
  const [productionCount, setProductionCount] = useState<number>(0);
  const [averageWeight, setAverageWeight] = useState<number>(1.5);
  const [observations, setObservations] = useState('');

  const [loading, setLoading] = useState(false);
  const [isAdding, setIsAdding] = useState(false);

  // Filter for selected farm
  const activeRecords = dailyRecords.filter(r => r.farmId === selectedFarmId);

  // Recharts consumption chart data
  const chartData = activeRecords.slice(-7).map(r => ({
    date: r.date,
    feed: r.feedConsumption,
    water: r.waterConsumption
  })).sort((a, b) => a.date.localeCompare(b.date));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFarmId) {
      alert('Please select a farm first.');
      return;
    }
    setLoading(true);
    try {
      await onAddDailyRecord({
        farmId: selectedFarmId,
        date,
        feedConsumption: Number(feedConsumption),
        waterConsumption: Number(waterConsumption),
        mortalityCount: Number(mortalityCount),
        productionCount: Number(productionCount),
        averageWeight: Number(averageWeight),
        observations: observations.trim()
      });

      // Reset
      setObservations('');
      setMortalityCount(0);
      setProductionCount(0);
      setIsAdding(false);
    } catch (err: any) {
      alert(err.message || 'Failed to submit daily record.');
    } finally {
      setLoading(false);
    }
  };

  const selectedFarmObj = farms.find(f => f.id === selectedFarmId);
  const isPoultry = selectedFarmObj?.farmType === 'Poultry';

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-6"
    >
      {/* Header Selector bar */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm flex flex-col sm:flex-row justify-between items-center gap-4">
        <div className="flex items-center gap-3">
          <Clipboard className="h-6 w-6 text-emerald-600 shrink-0" />
          <div>
            <h3 className="font-extrabold text-stone-900 text-sm sm:text-base">Daily Farm Record Portal</h3>
            <p className="text-stone-500 text-xs">Maintain logs of feed/water consumption, track weights, record mortality, and log egg/meat production</p>
          </div>
        </div>
        <div className="w-full sm:w-auto flex gap-2">
          <select
            value={selectedFarmId}
            onChange={(e) => setSelectedFarmId(e.target.value)}
            className="w-full sm:w-64 px-3 py-2 border border-stone-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold bg-stone-50"
          >
            {farms.length === 0 ? (
              <option value="">No registered farms found</option>
            ) : (
              farms.map(f => (
                <option key={f.id} value={f.id}>
                  {f.name} ({f.farmType})
                </option>
              ))
            )}
          </select>
          {farms.length > 0 && !isAdding && (
            <button
              onClick={() => setIsAdding(true)}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl flex items-center gap-1 shrink-0 transition shadow-sm cursor-pointer"
            >
              <Plus className="h-4 w-4" />
              New Record
            </button>
          )}
        </div>
      </div>

      {farms.length === 0 ? (
        <div className="text-center py-16 bg-white border border-stone-200 rounded-2xl">
          <ShieldAlert className="h-12 w-12 text-stone-300 mx-auto mb-3" />
          <p className="font-bold text-stone-700">Please Register a Farm Unit First</p>
          <p className="text-stone-500 text-xs mt-1">Configure a farm first to begin daily productivity logging.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* DAILY RECORD LOGGER FORM */}
          {isAdding && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white p-6 rounded-2xl border border-stone-200 shadow-md space-y-4 h-fit"
            >
              <div className="flex justify-between items-center pb-2 border-b border-stone-100">
                <h4 className="font-bold text-stone-900 text-sm flex items-center gap-1">
                  <Plus className="h-4 w-4 text-emerald-600" />
                  Log Daily Metrics
                </h4>
                <button 
                  onClick={() => setIsAdding(false)}
                  className="text-stone-400 hover:text-stone-600 text-xs font-bold"
                >
                  Close
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4 text-xs">
                
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-stone-700 flex items-center gap-1">
                    <Calendar className="h-3.5 w-3.5" /> Date of Log
                  </label>
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-3 py-2 border border-stone-200 rounded-lg focus:ring-emerald-500 focus:outline-none focus:ring-2 font-mono font-bold"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-700 block">Feed Consumption (kg)</label>
                    <input
                      type="number"
                      value={feedConsumption}
                      onChange={(e) => setFeedConsumption(Number(e.target.value))}
                      min={0}
                      className="w-full px-3 py-2 border border-stone-200 rounded-lg focus:ring-emerald-500 focus:outline-none focus:ring-2"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-700 block">Water Consumption (L)</label>
                    <input
                      type="number"
                      value={waterConsumption}
                      onChange={(e) => setWaterConsumption(Number(e.target.value))}
                      min={0}
                      className="w-full px-3 py-2 border border-stone-200 rounded-lg focus:ring-emerald-500 focus:outline-none focus:ring-2"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-700 block">Mortality Count (heads)</label>
                    <input
                      type="number"
                      value={mortalityCount}
                      onChange={(e) => setMortalityCount(Number(e.target.value))}
                      min={0}
                      className="w-full px-3 py-2 border border-stone-200 rounded-lg focus:ring-emerald-500 focus:outline-none focus:ring-2"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-700 block">Average Weight (kg)</label>
                    <input
                      type="number"
                      value={averageWeight}
                      onChange={(e) => setAverageWeight(Number(e.target.value))}
                      step={0.01}
                      min={0.01}
                      className="w-full px-3 py-2 border border-stone-200 rounded-lg focus:ring-emerald-500 focus:outline-none focus:ring-2"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-stone-700 block">
                    {isPoultry ? 'Production Count (e.g., eggs harvested)' : 'Production Logs (e.g., liters / count)'}
                  </label>
                  <input
                    type="number"
                    value={productionCount}
                    onChange={(e) => setProductionCount(Number(e.target.value))}
                    min={0}
                    className="w-full px-3 py-2 border border-stone-200 rounded-lg focus:ring-emerald-500 focus:outline-none focus:ring-2"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-stone-700 block">Health Observations & Notes</label>
                  <textarea
                    value={observations}
                    onChange={(e) => setObservations(e.target.value)}
                    placeholder="e.g. Normal behavior, slight cough in row B..."
                    className="w-full px-3 py-2 border border-stone-200 rounded-lg focus:ring-emerald-500 focus:outline-none focus:ring-2 h-16 resize-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-sm transition uppercase tracking-wide cursor-pointer"
                >
                  {loading ? 'Recording...' : 'File Daily Report'}
                </button>
              </form>
            </motion.div>
          )}

          {/* ANALYTICS & GRID VIEW */}
          <div className={`${isAdding ? 'lg:col-span-2' : 'lg:col-span-3'} space-y-6`}>
            
            {/* Recharts Analytics chart */}
            {chartData.length > 0 && (
              <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
                <h4 className="font-extrabold text-stone-900 text-base mb-1 flex items-center gap-2">
                  <BarChart2 className="h-5 w-5 text-emerald-600" />
                  Feed & Water Intake Ratio
                </h4>
                <p className="text-stone-500 text-xs mb-4">Historical daily consumption averages</p>

                <div className="h-60">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f5f5f4" vertical={false} />
                      <XAxis dataKey="date" stroke="#a8a29e" fontSize={10} tickLine={false} />
                      <YAxis stroke="#a8a29e" fontSize={10} tickLine={false} />
                      <Tooltip contentStyle={{ backgroundColor: '#ffffff', borderRadius: '12px', border: '1px solid #e7e5e4', fontSize: '11px' }} />
                      <Legend wrapperStyle={{ fontSize: '11px' }} />
                      <Bar dataKey="feed" name="Feed (kg)" fill="#059669" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="water" name="Water (Liters)" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}

            {/* Historical Entries Table */}
            <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
              <h4 className="font-extrabold text-stone-900 text-base mb-1 flex items-center gap-2">
                <Activity className="h-5 w-5 text-emerald-600" />
                Historical Performance Logs
              </h4>
              <p className="text-stone-500 text-xs mb-4">Detailed records of animal metrics and husbandry logs</p>

              {activeRecords.length === 0 ? (
                <div className="text-center py-12 text-stone-400 text-xs">
                  No daily records entered yet. Click "New Record" to begin entering metrics.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-stone-50 text-stone-500 font-bold uppercase tracking-wider text-[10px] border-b border-stone-100">
                        <th className="py-3 px-4">Date</th>
                        <th className="py-3 px-4">Feed Intake (kg)</th>
                        <th className="py-3 px-4">Water Intake (L)</th>
                        <th className="py-3 px-4">Mortality</th>
                        <th className="py-3 px-4">Avg Weight (kg)</th>
                        {isPoultry && <th className="py-3 px-4">Production (eggs)</th>}
                        <th className="py-3 px-4">Observations</th>
                        <th className="py-3 px-4">Logged By</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-50">
                      {activeRecords.slice().reverse().map((r) => (
                        <tr key={r.id} className="hover:bg-stone-50/50">
                          <td className="py-3 px-4 font-mono font-bold text-stone-900">{r.date}</td>
                          <td className="py-3 px-4 font-semibold text-stone-700">{r.feedConsumption}</td>
                          <td className="py-3 px-4 text-stone-600">{r.waterConsumption}</td>
                          <td className={`py-3 px-4 font-bold ${r.mortalityCount > 0 ? 'text-rose-600 bg-rose-50/20' : 'text-stone-600'}`}>{r.mortalityCount}</td>
                          <td className="py-3 px-4 font-bold text-stone-900">{r.averageWeight}</td>
                          {isPoultry && <td className="py-3 px-4 font-bold text-emerald-600">{r.productionCount}</td>}
                          <td className="py-3 px-4 text-stone-500 max-w-xs truncate" title={r.observations}>{r.observations || '-'}</td>
                          <td className="py-3 px-4 text-stone-500 font-medium">{r.recordedBy}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

          </div>

        </div>
      )}

    </motion.div>
  );
}
