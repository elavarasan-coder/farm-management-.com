import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Sprout, 
  Plus, 
  Edit2, 
  Trash2, 
  MapPin, 
  Check, 
  X, 
  ShieldAlert,
  Map as MapIcon,
  Grid as GridIcon
} from 'lucide-react';
import { Farm, FarmType, Role } from '../types';
import FarmMap from './FarmMap';

interface FarmManagementProps {
  farms: Farm[];
  role: Role;
  onAddFarm: (farm: Omit<Farm, 'id' | 'ownerId' | 'createdAt'>) => Promise<void>;
  onEditFarm: (id: string, updated: Partial<Farm>) => Promise<void>;
  onDeleteFarm: (id: string) => Promise<void>;
}

export default function FarmManagement({ 
  farms, 
  role,
  onAddFarm, 
  onEditFarm, 
  onDeleteFarm 
}: FarmManagementProps) {
  
  // States
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'map'>('map');
  
  // Add Form state
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');
  const [latitude, setLatitude] = useState<number | undefined>(undefined);
  const [longitude, setLongitude] = useState<number | undefined>(undefined);
  const [animalCount, setAnimalCount] = useState<number>(100);
  const [farmType, setFarmType] = useState<FarmType>('Pig');
  
  // Edit Form state
  const [editName, setEditName] = useState('');
  const [editLocation, setEditLocation] = useState('');
  const [editLatitude, setEditLatitude] = useState<number | undefined>(undefined);
  const [editLongitude, setEditLongitude] = useState<number | undefined>(undefined);
  const [editAnimalCount, setEditAnimalCount] = useState<number>(100);
  const [editFarmType, setEditFarmType] = useState<FarmType>('Pig');

  const [formError, setFormError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Check roles permissions
  const canModify = role === 'Farmer' || role === 'Administrator';

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (!name.trim() || !location.trim()) {
      setFormError('Name and Location are required.');
      return;
    }
    if (animalCount <= 0) {
      setFormError('Animal count must be greater than 0.');
      return;
    }

    setLoading(true);
    try {
      await onAddFarm({
        name: name.trim(),
        location: location.trim(),
        latitude: latitude ? Number(latitude) : undefined,
        longitude: longitude ? Number(longitude) : undefined,
        animalCount: Number(animalCount),
        farmType
      });
      // Reset
      setName('');
      setLocation('');
      setLatitude(undefined);
      setLongitude(undefined);
      setAnimalCount(100);
      setFarmType('Pig');
      setIsAdding(false);
    } catch (err: any) {
      setFormError(err.message || 'Failed to add farm.');
    } finally {
      setLoading(false);
    }
  };

  const handleStartEdit = (farm: Farm) => {
    setEditingId(farm.id);
    setEditName(farm.name);
    setEditLocation(farm.location);
    setEditLatitude(farm.latitude);
    setEditLongitude(farm.longitude);
    setEditAnimalCount(farm.animalCount);
    setEditFarmType(farm.farmType);
  };

  const handleSaveEdit = async (id: string) => {
    setFormError(null);
    if (!editName.trim() || !editLocation.trim()) {
      setFormError('Name and Location are required.');
      return;
    }
    setLoading(true);
    try {
      await onEditFarm(id, {
        name: editName.trim(),
        location: editLocation.trim(),
        latitude: editLatitude ? Number(editLatitude) : undefined,
        longitude: editLongitude ? Number(editLongitude) : undefined,
        animalCount: Number(editAnimalCount),
        farmType: editFarmType
      });
      setEditingId(null);
    } catch (err: any) {
      setFormError(err.message || 'Failed to update farm.');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you absolutely sure you want to delete this farm? This action will permanently remove all associated daily logs, health files, and vaccination schedules.')) {
      setLoading(true);
      try {
        await onDeleteFarm(id);
      } catch (err: any) {
        alert(err.message || 'Failed to delete farm.');
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-6"
    >
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-stone-900 tracking-tight">Farm Management</h2>
          <p className="text-stone-500 text-sm">Register, monitor, and configure livestock facilities</p>
        </div>
        <div className="flex items-center gap-2.5 self-stretch sm:self-auto justify-between sm:justify-start">
          {farms.length > 0 && (
            <div className="bg-stone-100 dark:bg-stone-850 p-1 rounded-xl flex gap-1 border border-stone-200/30">
              <button
                onClick={() => setViewMode('map')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  viewMode === 'map' 
                    ? 'bg-white dark:bg-stone-900 text-emerald-800 dark:text-emerald-400 shadow-sm' 
                    : 'text-stone-500 hover:text-stone-700 dark:text-stone-400 dark:hover:text-stone-300'
                }`}
              >
                <MapIcon className="h-4 w-4" />
                Interactive Map
              </button>
              <button
                onClick={() => setViewMode('grid')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  viewMode === 'grid' 
                    ? 'bg-white dark:bg-stone-900 text-emerald-800 dark:text-emerald-400 shadow-sm' 
                    : 'text-stone-500 hover:text-stone-700 dark:text-stone-400 dark:hover:text-stone-300'
                }`}
              >
                <GridIcon className="h-4 w-4" />
                Grid Cards
              </button>
            </div>
          )}

          {canModify && !isAdding && (
            <button
              onClick={() => setIsAdding(true)}
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-4 py-2.5 rounded-xl text-sm transition shadow-sm hover:shadow cursor-pointer"
            >
              <Plus className="h-4.5 w-4.5" />
              Add New Farm
            </button>
          )}
        </div>
      </div>

      {formError && (
        <div className="bg-rose-50 border border-rose-200 text-rose-800 text-xs p-4 rounded-xl flex items-center gap-3">
          <ShieldAlert className="h-4.5 w-4.5 text-rose-600 shrink-0" />
          <span>{formError}</span>
        </div>
      )}

      {/* Add New Farm Dialog/Box */}
      {isAdding && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-6 rounded-2xl border border-emerald-100 shadow-md space-y-4"
        >
          <div className="flex justify-between items-center pb-3 border-b border-stone-100">
            <h3 className="font-bold text-stone-900 text-base">Register New Farm Unit</h3>
            <button 
              onClick={() => setIsAdding(false)}
              className="text-stone-400 hover:text-stone-600 p-1 rounded-lg"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          <form onSubmit={handleCreate} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-stone-700 block">Farm Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Greenwood Poultry East"
                className="w-full px-3.5 py-2 border border-stone-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-stone-700 block">Geographic Location</label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="e.g. Sector 4, Oregon County"
                className="w-full px-3.5 py-2 border border-stone-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-stone-700 block">Initial Animal Count</label>
              <input
                type="number"
                value={animalCount}
                onChange={(e) => setAnimalCount(Number(e.target.value))}
                min={1}
                className="w-full px-3.5 py-2 border border-stone-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-stone-700 block">Livestock Farm Type</label>
              <div className="grid grid-cols-2 gap-2 mt-1">
                <button
                  type="button"
                  onClick={() => setFarmType('Pig')}
                  className={`py-2 px-4 rounded-lg font-bold text-xs text-center border transition ${
                    farmType === 'Pig' 
                      ? 'bg-emerald-50 border-emerald-500 text-emerald-800' 
                      : 'border-stone-200 text-stone-600 hover:bg-stone-50'
                  }`}
                >
                  🐷 Pig / Swine
                </button>
                <button
                  type="button"
                  onClick={() => setFarmType('Poultry')}
                  className={`py-2 px-4 rounded-lg font-bold text-xs text-center border transition ${
                    farmType === 'Poultry' 
                      ? 'bg-amber-50 border-amber-500 text-amber-800' 
                      : 'border-stone-200 text-stone-600 hover:bg-stone-50'
                  }`}
                >
                  🐔 Poultry / Fowl
                </button>
              </div>
            </div>

            {/* Google Map Section for Pinning the Land */}
            <div className="md:col-span-2 space-y-2 border-t border-stone-100 pt-4">
              <label className="text-xs font-bold text-stone-700 block">Pin Land Location on Google Map</label>
              <div className="text-[10px] text-stone-500 font-medium pb-1">
                Use the search tool or click anywhere on the map below to instantly pin your farm location. You can drag the red pin to select your boundaries accurately.
              </div>
              <FarmMap 
                farms={[]} 
                interactiveMode={true}
                selectedLat={latitude}
                selectedLng={longitude}
                onSelectCoordinates={(lat, lng, address) => {
                  setLatitude(lat);
                  setLongitude(lng);
                  if (address) {
                    setLocation(address);
                  }
                }}
                height="280px"
              />
              <div className="grid grid-cols-2 gap-4 pt-1">
                <div className="space-y-1">
                  <label className="text-[10px] font-mono uppercase tracking-wider text-stone-500 block">Latitude</label>
                  <input
                    type="number"
                    step="any"
                    value={latitude || ''}
                    onChange={(e) => setLatitude(e.target.value ? Number(e.target.value) : undefined)}
                    placeholder="e.g. 44.9778"
                    className="w-full px-3 py-1.5 border border-stone-200 rounded-lg text-xs font-mono bg-stone-50/50 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-mono uppercase tracking-wider text-stone-500 block">Longitude</label>
                  <input
                    type="number"
                    step="any"
                    value={longitude || ''}
                    onChange={(e) => setLongitude(e.target.value ? Number(e.target.value) : undefined)}
                    placeholder="e.g. -123.0308"
                    className="w-full px-3 py-1.5 border border-stone-200 rounded-lg text-xs font-mono bg-stone-50/50 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>
            </div>

            <div className="md:col-span-2 flex justify-end gap-3 pt-3 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setIsAdding(false)}
                className="px-4 py-2 border border-stone-200 text-stone-600 font-bold text-xs rounded-lg hover:bg-stone-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg transition"
              >
                {loading ? 'Creating...' : 'Register Farm'}
              </button>
            </div>
          </form>
        </motion.div>
      )}

      {/* Farms List / Grid / Map */}
      {farms.length === 0 ? (
        <div className="text-center py-16 bg-white border border-stone-200 rounded-2xl shadow-sm">
          <div className="mx-auto h-12 w-12 text-stone-300 mb-3">
            <Sprout className="h-12 w-12" />
          </div>
          <h3 className="text-stone-800 font-bold text-base">No Farms Registered</h3>
          <p className="text-stone-500 text-xs mt-1 max-w-sm mx-auto">
            You don't have any registered facilities yet. Add your first pig or poultry farm unit to get started.
          </p>
          {canModify && (
            <button
              onClick={() => setIsAdding(true)}
              className="mt-4 px-4 py-2 bg-emerald-600 text-white font-bold text-xs rounded-lg hover:bg-emerald-700 transition cursor-pointer"
            >
              Add First Farm
            </button>
          )}
        </div>
      ) : viewMode === 'map' && !isAdding ? (
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white dark:bg-stone-900 border border-stone-200/50 dark:border-stone-800 p-4.5 rounded-3xl shadow-sm"
        >
          <FarmMap farms={farms} height="480px" />
        </motion.div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {farms.map((farm) => {
            const isEditing = editingId === farm.id;
            const isPig = farm.farmType === 'Pig';

            return (
              <div 
                key={farm.id}
                className={`bg-white border p-6 rounded-2xl shadow-sm hover:shadow-md transition relative flex flex-col justify-between ${
                  isEditing ? 'border-emerald-500 ring-2 ring-emerald-50' : 'border-stone-200'
                }`}
              >
                {isEditing ? (
                  // Inline Edit View
                  <div className="space-y-3">
                    <input
                      type="text"
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      className="w-full px-2 py-1.5 border border-stone-300 rounded-lg text-sm"
                      placeholder="Name"
                    />
                    <input
                      type="text"
                      value={editLocation}
                      onChange={(e) => setEditLocation(e.target.value)}
                      className="w-full px-2 py-1.5 border border-stone-300 rounded-lg text-sm"
                      placeholder="Location"
                    />
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="number"
                        value={editAnimalCount}
                        onChange={(e) => setEditAnimalCount(Number(e.target.value))}
                        className="w-full px-2 py-1.5 border border-stone-300 rounded-lg text-sm"
                        placeholder="Count"
                      />
                      <select
                        value={editFarmType}
                        onChange={(e) => setEditFarmType(e.target.value as FarmType)}
                        className="w-full px-2 py-1.5 border border-stone-300 rounded-lg text-sm"
                      >
                        <option value="Pig">Pig / Swine</option>
                        <option value="Poultry">Poultry / Fowl</option>
                      </select>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <input
                        type="number"
                        step="any"
                        value={editLatitude || ''}
                        onChange={(e) => setEditLatitude(e.target.value ? Number(e.target.value) : undefined)}
                        className="w-full px-2 py-1.5 border border-stone-300 rounded-lg text-xs font-mono"
                        placeholder="Lat (Optional)"
                      />
                      <input
                        type="number"
                        step="any"
                        value={editLongitude || ''}
                        onChange={(e) => setEditLongitude(e.target.value ? Number(e.target.value) : undefined)}
                        className="w-full px-2 py-1.5 border border-stone-300 rounded-lg text-xs font-mono"
                        placeholder="Lng (Optional)"
                      />
                    </div>

                    <div className="flex justify-end gap-2 pt-2">
                      <button
                        onClick={() => setEditingId(null)}
                        className="p-1.5 border border-stone-200 rounded-lg text-stone-500 hover:bg-stone-50"
                      >
                        <X className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => handleSaveEdit(farm.id)}
                        disabled={loading}
                        className="p-1.5 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700"
                      >
                        <Check className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ) : (
                  // Default View
                  <>
                    <div className="space-y-4">
                      {/* Top Header */}
                      <div className="flex justify-between items-start">
                        <div className="space-y-1">
                          <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                            isPig 
                              ? 'bg-emerald-50 border-emerald-100 text-emerald-800' 
                              : 'bg-amber-50 border-amber-100 text-amber-800'
                          }`}>
                            {isPig ? '🐷 Swine' : '🐔 Poultry'}
                          </span>
                          <h4 className="text-lg font-black text-stone-900 tracking-tight mt-1">{farm.name}</h4>
                        </div>
                        {canModify && (
                          <div className="flex gap-1">
                            <button
                              onClick={() => handleStartEdit(farm)}
                              className="p-1.5 text-stone-400 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition"
                              title="Edit Farm"
                            >
                              <Edit2 className="h-4 w-4" />
                            </button>
                            <button
                              onClick={() => handleDelete(farm.id)}
                              className="p-1.5 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                              title="Delete Farm"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        )}
                      </div>

                      {/* Info lines */}
                      <div className="space-y-2 pt-1 border-t border-stone-50">
                        <div className="flex items-center gap-2 text-stone-600 text-xs font-medium">
                          <MapPin className="h-4 w-4 text-stone-400 shrink-0" />
                          <span className="truncate">{farm.location}</span>
                        </div>
                        {farm.latitude && farm.longitude && (
                          <div className="flex items-center justify-between text-[10px] text-stone-500 font-mono">
                            <span>🛰️ {farm.latitude.toFixed(4)}, {farm.longitude.toFixed(4)}</span>
                            <button
                              onClick={() => setViewMode('map')}
                              className="text-emerald-700 hover:underline font-bold cursor-pointer"
                            >
                              Show on Map &rarr;
                            </button>
                          </div>
                        )}
                        <div className="flex justify-between items-center text-xs pt-1">
                          <span className="text-stone-400 uppercase font-bold tracking-wider text-[10px]">LIVESTOCK HEADCOUNT</span>
                          <span className="font-extrabold text-stone-900 bg-stone-100 px-2 py-1 rounded text-xs">
                            {farm.animalCount.toLocaleString()} {isPig ? 'pigs' : 'birds'}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-stone-50 text-[10px] text-stone-400 flex justify-between items-center">
                      <span>Owner ID: {farm.ownerId.slice(0, 8)}...</span>
                      <span>{new Date(farm.createdAt).toLocaleDateString()}</span>
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </div>
      )}
    </motion.div>
  );
}
