export type Role = 'Farmer' | 'Farm Manager' | 'Administrator';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: Role;
  createdAt: string;
}

export type FarmType = 'Pig' | 'Poultry';

export interface Farm {
  id: string;
  name: string;
  location: string;
  latitude?: number;
  longitude?: number;
  animalCount: number;
  farmType: FarmType;
  ownerId: string;
  createdAt: string;
}

export interface VisitorLog {
  id: string;
  farmId: string;
  visitorName: string;
  purpose: string;
  entryTime: string;
  cleared: boolean;
  loggedBy: string;
}

export interface BiosecurityChecklist {
  id: string;
  farmId: string;
  date: string;
  visitorEntryLog: boolean;
  footbathMaintenance: boolean;
  handSanitization: boolean;
  protectiveClothing: boolean;
  vehicleDisinfection: boolean;
  equipmentCleaning: boolean;
  feedInspection: boolean;
  waterInspection: boolean;
  wasteMonitoring: boolean;
  deadAnimalDisposal: boolean;
  compliancePercentage: number;
  status: 'green' | 'yellow' | 'red';
  completedBy: string;
  createdAt: string;
}

export interface HealthRecord {
  id: string;
  farmId: string;
  disease: string;
  symptoms: string;
  treatment: string;
  medicineDetails: string;
  veterinaryVisitHistory: string;
  photoUrl?: string;
  recordedBy: string;
  createdAt: string;
}

export type VaccinationStatus = 'scheduled' | 'completed' | 'overdue';

export interface Vaccination {
  id: string;
  farmId: string;
  vaccineName: string;
  scheduleDate: string;
  nextDueDate: string;
  status: VaccinationStatus;
  notes: string;
  recordedBy: string;
  createdAt: string;
}

export interface DailyRecord {
  id: string;
  farmId: string;
  date: string;
  feedConsumption: number; // in kg
  waterConsumption: number; // in liters
  mortalityCount: number;
  productionCount: number; // eggs or output units
  averageWeight: number; // in kg
  observations: string;
  recordedBy: string;
  createdAt: string;
}

export interface SystemNotification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'alert' | 'success';
  createdAt: string;
  read: boolean;
}
