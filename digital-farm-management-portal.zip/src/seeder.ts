import { db } from './firebase';
import { collection, doc, setDoc, writeBatch } from 'firebase/firestore';
import { Farm, BiosecurityChecklist, VisitorLog, HealthRecord, Vaccination, DailyRecord } from './types';

export const seedMockData = async (userId: string) => {
  const batch = writeBatch(db);

  // 1. CREATE TWO FARMS
  const farm1Id = 'farm_swine_001';
  const farm2Id = 'farm_poultry_002';

  const farm1Ref = doc(db, 'farms', farm1Id);
  const farm2Ref = doc(db, 'farms', farm2Id);

  const farm1Data: Farm = {
    id: farm1Id,
    name: 'Greensward Swine Facility',
    location: 'Oregon Sector A, Lane 5',
    latitude: 44.9778,
    longitude: -123.0308,
    animalCount: 420,
    farmType: 'Pig',
    ownerId: userId,
    createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString()
  };

  const farm2Data: Farm = {
    id: farm2Id,
    name: 'Apex Laying Complex',
    location: 'Washington Wing B, Unit 2',
    latitude: 47.7511,
    longitude: -120.7401,
    animalCount: 1850,
    farmType: 'Poultry',
    ownerId: userId,
    createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString()
  };

  batch.set(farm1Ref, farm1Data);
  batch.set(farm2Ref, farm2Data);

  // 2. DAILY BIOSECURITY CHECKLISTS FOR COHESIVE GRAPHS (LAST 5 DAYS)
  const days = [5, 4, 3, 2, 1, 0];
  const completedBy = 'Demo Manager';

  days.forEach((day, index) => {
    const checklist1Id = `chk_swine_${day}`;
    const checklist2Id = `chk_poultry_${day}`;

    const dateStr = new Date(Date.now() - day * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const createdAt = new Date(Date.now() - day * 24 * 60 * 60 * 1000).toISOString();

    // Fluctuating compliance scores
    const swineScore = index === 0 ? 80 : index === 1 ? 90 : index === 2 ? 100 : index === 3 ? 90 : 100;
    const poultryScore = index === 0 ? 70 : index === 1 ? 80 : index === 2 ? 90 : index === 3 ? 100 : 100;

    const checklist1: BiosecurityChecklist = {
      id: checklist1Id,
      farmId: farm1Id,
      date: dateStr,
      visitorEntryLog: true,
      footbathMaintenance: swineScore >= 80,
      handSanitization: true,
      protectiveClothing: swineScore >= 90,
      vehicleDisinfection: swineScore === 100,
      equipmentCleaning: true,
      feedInspection: true,
      waterInspection: true,
      wasteMonitoring: swineScore >= 90,
      deadAnimalDisposal: true,
      compliancePercentage: swineScore,
      status: swineScore >= 90 ? 'green' : swineScore >= 70 ? 'yellow' : 'red',
      completedBy,
      createdAt
    };

    const checklist2: BiosecurityChecklist = {
      id: checklist2Id,
      farmId: farm2Id,
      date: dateStr,
      visitorEntryLog: true,
      footbathMaintenance: poultryScore >= 80,
      handSanitization: true,
      protectiveClothing: poultryScore >= 90,
      vehicleDisinfection: poultryScore === 100,
      equipmentCleaning: true,
      feedInspection: true,
      waterInspection: poultryScore >= 80,
      wasteMonitoring: true,
      deadAnimalDisposal: true,
      compliancePercentage: poultryScore,
      status: poultryScore >= 90 ? 'green' : poultryScore >= 70 ? 'yellow' : 'red',
      completedBy,
      createdAt
    };

    batch.set(doc(db, 'farms', farm1Id, 'biosecurityChecklists', checklist1Id), checklist1);
    batch.set(doc(db, 'farms', farm2Id, 'biosecurityChecklists', checklist2Id), checklist2);
  });

  // 3. VISITOR LOGS
  const log1Id = 'vlog_001';
  const log2Id = 'vlog_002';
  const log3Id = 'vlog_003';

  const visitor1: VisitorLog = {
    id: log1Id,
    farmId: farm1Id,
    visitorName: 'Dr. Evelyn Martinez',
    purpose: 'Routine Swine Health Exam',
    entryTime: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    cleared: true,
    loggedBy: 'Demo Farmer'
  };

  const visitor2: VisitorLog = {
    id: log2Id,
    farmId: farm1Id,
    visitorName: 'Apex Feed Truck (Driver Joe)',
    purpose: 'Feed Silo Replenishment',
    entryTime: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    cleared: true,
    loggedBy: 'Demo Farmer'
  };

  const visitor3: VisitorLog = {
    id: log3Id,
    farmId: farm2Id,
    visitorName: 'Local Contractor',
    purpose: 'Fan Ventilator Maintenance',
    entryTime: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
    cleared: false, // Refused protective suit
    loggedBy: 'Demo Manager'
  };

  batch.set(doc(db, 'farms', farm1Id, 'visitorLogs', log1Id), visitor1);
  batch.set(doc(db, 'farms', farm1Id, 'visitorLogs', log2Id), visitor2);
  batch.set(doc(db, 'farms', farm2Id, 'visitorLogs', log3Id), visitor3);

  // 4. ANIMAL HEALTH RECORDS
  const h1Id = 'health_001';
  const h2Id = 'health_002';

  const health1: HealthRecord = {
    id: h1Id,
    farmId: farm1Id,
    disease: 'Mange (Sarcoptes scabiei)',
    symptoms: 'Intense scratching, skin inflammation, lesions near ears',
    treatment: 'Isolation of infected piglet pen, topical ivermectin dose',
    medicineDetails: 'Topical ivermectin, administered once',
    veterinaryVisitHistory: 'Examined by Dr Evelyn, pen quarantine ordered',
    photoUrl: 'https://images.unsplash.com/photo-1605001011156-cbf0b0f67a51?w=150&auto=format&fit=crop&q=60&ixlib=rb-4.0.3',
    recordedBy: 'Demo Farmer',
    createdAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString()
  };

  const health2: HealthRecord = {
    id: h2Id,
    farmId: farm2Id,
    disease: 'Coccidiosis (Poultry)',
    symptoms: 'Diarrhea, pale combs, severe lethargy in sector D',
    treatment: 'Amprolium solution treatment added to shared water silos',
    medicineDetails: 'Amprolium 9.6% solution for 5 days',
    veterinaryVisitHistory: 'Coordinated via phone consultation, quarantine active',
    photoUrl: 'https://images.unsplash.com/photo-1548767797-d8c844163c4c?w=150&auto=format&fit=crop&q=60&ixlib=rb-4.0.3',
    recordedBy: 'Demo Manager',
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString()
  };

  batch.set(doc(db, 'farms', farm1Id, 'healthRecords', h1Id), health1);
  batch.set(doc(db, 'farms', farm2Id, 'healthRecords', h2Id), health2);

  // 5. VACCINATION SCHEDULES
  const v1Id = 'vacc_001';
  const v2Id = 'vacc_002';
  const v3Id = 'vacc_003';

  const vacc1: Vaccination = {
    id: v1Id,
    farmId: farm1Id,
    vaccineName: 'Swine Erysipelas Vaccine',
    scheduleDate: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    nextDueDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    status: 'scheduled',
    notes: '2ml subcutaneous injection. Ensure stock is healthy before dosing.',
    recordedBy: 'Demo Farmer',
    createdAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000).toISOString()
  };

  const vacc2: Vaccination = {
    id: v2Id,
    farmId: farm1Id,
    vaccineName: 'Mycoplasma Hyopneumoniae Booster',
    scheduleDate: new Date(Date.now() - 35 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    nextDueDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    status: 'overdue',
    notes: 'Booster required for replacement gilts.',
    recordedBy: 'Demo Farmer',
    createdAt: new Date(Date.now() - 35 * 24 * 60 * 60 * 1000).toISOString()
  };

  const vacc3: Vaccination = {
    id: v3Id,
    farmId: farm2Id,
    vaccineName: 'Newcastle Disease Immunisation',
    scheduleDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    nextDueDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    status: 'completed',
    notes: 'Drinking water mass application completed successfully.',
    recordedBy: 'Demo Manager',
    createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString()
  };

  batch.set(doc(db, 'farms', farm1Id, 'vaccinations', v1Id), vacc1);
  batch.set(doc(db, 'farms', farm1Id, 'vaccinations', v2Id), vacc2);
  batch.set(doc(db, 'farms', farm2Id, 'vaccinations', v3Id), vacc3);

  // 6. DAILY PERFORMANCE RECORDS (LAST 5 DAYS)
  days.forEach((day) => {
    const dRec1Id = `drec_swine_${day}`;
    const dRec2Id = `drec_poultry_${day}`;

    const dateStr = new Date(Date.now() - day * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const createdAt = new Date(Date.now() - day * 24 * 60 * 60 * 1000).toISOString();

    const daily1: DailyRecord = {
      id: dRec1Id,
      farmId: farm1Id,
      date: dateStr,
      feedConsumption: 620 - day * 10, // slightly fluctuating
      waterConsumption: 1850 - day * 15,
      mortalityCount: day === 2 ? 1 : 0, // 1 mortality on day 2
      productionCount: 0,
      averageWeight: 84.5 + (5 - day) * 0.4, // growing pigs
      observations: 'Pigs are highly active. Feed intake standard.',
      recordedBy: 'Demo Farmer',
      createdAt
    };

    const daily2: DailyRecord = {
      id: dRec2Id,
      farmId: farm2Id,
      date: dateStr,
      feedConsumption: 125 - day * 2,
      waterConsumption: 410 - day * 5,
      mortalityCount: 0,
      productionCount: 1420 + (5 - day) * 15, // laying hen production
      averageWeight: 1.82 + (5 - day) * 0.01,
      observations: 'Ventilation running at 100%. Egg harvesting smooth.',
      recordedBy: 'Demo Manager',
      createdAt
    };

    batch.set(doc(db, 'farms', farm1Id, 'dailyRecords', dRec1Id), daily1);
    batch.set(doc(db, 'farms', farm2Id, 'dailyRecords', dRec2Id), daily2);
  });

  await batch.commit();
};
